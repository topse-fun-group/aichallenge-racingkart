"""Unit tests for corner overtaking (pure Python, no rclpy).

Covers the corner-specific follow -> overtake trigger, the commit period that
keeps OvertakeState alive, and the has_future_width equal-width fix.
"""

import numpy as np
import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import (
    FollowState,
    OvertakeState,
    StateContext,
)

# A curvature comfortably past the corner threshold, and one comfortably inside it.
CORNER_KAPPA = 3.0 * states.OVERTAKE_CORNER_KAPPA
STRAIGHT_KAPPA = 0.1 * states.OVERTAKE_CORNER_KAPPA

WIDE = states.MIN_OVERTAKE_WIDTH_M + 0.5
NARROW = states.MIN_OVERTAKE_WIDTH_M - 0.5


def make_ctx(
    *,
    t=0.0,
    kappa=CORNER_KAPPA,
    left=WIDE,
    right=NARROW,
    distance=None,
    v_ego=8.0,
    v_lead=8.0,
    side_vehicle=False,
    left_side=False,
    right_side=False,
    is_colliding=False,
    e_y=0.0,
):
    """A follow-state context sitting behind a leader in a corner."""
    if distance is None:
        distance = states.OVERTAKE_CORNER_MAX_DIST_M - 1.0
    return StateContext(
        current_time_sec=t,
        dt=0.025,
        pose_x=0.0,
        pose_y=0.0,
        pose_theta=0.0,
        velocity=v_ego,
        is_colliding=is_colliding,
        path_psi=0.0,
        path_e_y=e_y,
        path_kappa=kappa,
        forward_vehicle_distance=distance,
        forward_vehicle_speed=v_lead,
        closest_forward_vehicle_speed=v_lead,
        overtake_width_left=left,
        overtake_width_right=right,
        min_forward_overtake_width=max(left, right),
        has_side_vehicle=side_vehicle,
        has_left_side_vehicle=left_side,
        has_right_side_vehicle=right_side,
    )


def follow_decision(**kwargs):
    return FollowState().check_transition(make_ctx(**kwargs))


# --- corner trigger -------------------------------------------------------

def test_fires_in_a_left_corner_when_the_inside_is_open():
    """kappa > 0 is a left corner, so the inside is the left side."""
    assert follow_decision(kappa=+CORNER_KAPPA, left=WIDE, right=NARROW) == "overtake"


def test_fires_in_a_right_corner_when_the_inside_is_open():
    assert follow_decision(kappa=-CORNER_KAPPA, left=NARROW, right=WIDE) == "overtake"


def test_does_not_dive_to_the_outside_when_only_the_outside_is_open():
    """The wider side in a corner is usually the outside — the longer arc.

    Attempting there needs a speed advantage we do not have, so the corner
    trigger must stay quiet and leave the call to the existing conditions.
    """
    assert follow_decision(kappa=+CORNER_KAPPA, left=NARROW, right=WIDE) != "overtake"
    assert follow_decision(kappa=-CORNER_KAPPA, left=WIDE, right=NARROW) != "overtake"


def test_does_not_fire_on_a_straight():
    assert follow_decision(kappa=STRAIGHT_KAPPA, left=WIDE, right=NARROW) != "overtake"


def test_does_not_fire_when_the_leader_is_too_far_ahead():
    far = states.OVERTAKE_CORNER_MAX_DIST_M + 1.0
    assert follow_decision(distance=far) != "overtake"


def test_does_not_fire_while_losing_ground_to_the_leader():
    """Relative speed below the margin means we cannot close on the inside line."""
    assert follow_decision(v_ego=6.0, v_lead=8.0) != "overtake"


def test_does_not_fire_with_a_vehicle_alongside():
    assert follow_decision(left_side=True) != "overtake"
    assert follow_decision(right_side=True) != "overtake"


def test_collision_still_wins_over_the_corner_trigger():
    assert follow_decision(is_colliding=True) == "recovery"


def test_corner_thresholds_are_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.OVERTAKE_CORNER_KAPPA
    try:
        states.OVERTAKE_CORNER_KAPPA = 10.0  # nothing counts as a corner any more
        assert follow_decision(kappa=+CORNER_KAPPA) != "overtake"
    finally:
        states.OVERTAKE_CORNER_KAPPA = original


# --- has_future_width equal-width fix -------------------------------------

def test_equal_widths_no_longer_block_overtaking_forever():
    """if/elif with no else left has_future_width False whenever left == right."""
    state = FollowState()
    ctx = make_ctx(
        kappa=STRAIGHT_KAPPA,   # keep the corner trigger out of the way
        left=WIDE,
        right=WIDE,             # exactly equal
        v_ego=8.0,
        v_lead=1.0,             # slow leader so the safe block can fire
        # is_same_lane is kept in the safe block and has no deadband, so e_y must
        # match the chosen side: left == right makes is_left False, needing e_y < 0.
        e_y=-0.5,
    )
    assert state.check_transition(ctx) == "overtake"


# --- commit period --------------------------------------------------------

def overtaking_at(t):
    state = OvertakeState()
    state.on_enter(make_ctx(t=t))
    return state


def narrow_ctx(t):
    """A leader ahead with neither side wide enough — the abort condition."""
    return make_ctx(t=t, left=NARROW, right=NARROW, distance=4.0)


def test_narrow_road_does_not_abort_during_the_commit_period():
    state = overtaking_at(0.0)
    half = 0.5 * states.OVERTAKE_COMMIT_SEC
    assert state.check_transition(narrow_ctx(half)) is None


def test_narrow_road_aborts_once_the_commit_period_has_passed():
    state = overtaking_at(0.0)
    past = states.OVERTAKE_COMMIT_SEC + 0.1
    assert state.check_transition(narrow_ctx(past)) == "follow"


def test_losing_sight_of_everyone_does_not_end_the_pass_during_the_commit():
    """Shifting 1.5-2 m sideways drops the leader out of both detection windows."""
    state = overtaking_at(0.0)
    lost = make_ctx(t=0.5 * states.OVERTAKE_COMMIT_SEC, distance=None)
    lost.forward_vehicle_distance = None
    lost.forward_vehicle_speed = None
    assert state.check_transition(lost) is None


def test_losing_sight_ends_the_pass_after_the_commit():
    state = overtaking_at(0.0)
    lost = make_ctx(t=states.OVERTAKE_COMMIT_SEC + 0.1)
    lost.forward_vehicle_distance = None
    lost.forward_vehicle_speed = None
    assert state.check_transition(lost) == "follow_path"


def test_collision_aborts_even_inside_the_commit_period():
    state = overtaking_at(0.0)
    ctx = narrow_ctx(0.1)
    ctx.is_colliding = True
    assert state.check_transition(ctx) == "recovery"


def test_commit_period_is_read_from_module_globals_at_call_time():
    original = states.OVERTAKE_COMMIT_SEC
    try:
        states.OVERTAKE_COMMIT_SEC = 0.0
        state = overtaking_at(0.0)
        assert state.check_transition(narrow_ctx(0.1)) == "follow"
    finally:
        states.OVERTAKE_COMMIT_SEC = original
