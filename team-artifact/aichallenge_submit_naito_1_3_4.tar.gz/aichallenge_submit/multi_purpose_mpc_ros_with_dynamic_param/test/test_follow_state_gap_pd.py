"""Unit tests for FollowState gap PD control (pure Python, no rclpy)."""

import numpy as np
import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import FollowState, StateContext


def make_ctx(
    *,
    gap=None,
    v_ego=5.0,
    v_lead=5.0,
    overtake_width=0.0,
    forward_distance=None,
):
    """Build a StateContext for the follow-distance PD.

    ``gap`` is the bumper-to-bumper distance; it is converted to the
    centre-to-centre ``forward_vehicle_distance`` the detector actually
    reports. Pass ``forward_distance`` instead to set it directly.
    """
    if forward_distance is None and gap is not None:
        forward_distance = gap + states.VEHICLE_LENGTH

    return StateContext(
        current_time_sec=0.0,
        dt=0.02,
        state_id="ego",
        pose_x=0.0,
        pose_y=0.0,
        pose_theta=0.0,
        velocity=v_ego,
        is_colliding=False,
        forward_vehicle_distance=forward_distance,
        forward_vehicle_speed=None if forward_distance is None else v_lead,
        min_forward_overtake_width=overtake_width,
    )


def v_cmd(**kwargs):
    return FollowState().get_adjusted_v_max_mps(make_ctx(**kwargs))


def test_settles_at_target_gap_with_no_steady_state_error():
    """At the target gap and matched speed, command equals the leader speed."""
    assert v_cmd(gap=states.FOLLOW_TARGET_DISTANCE_M, v_ego=5.0, v_lead=5.0) == pytest.approx(5.0)


def test_brakes_to_zero_when_too_close_to_a_stopped_leader():
    assert v_cmd(gap=1.0, v_ego=5.0, v_lead=0.0) == 0.0


def test_never_negative_even_when_bumpers_overlap():
    """distance < VEHICLE_LENGTH must not produce a negative command."""
    assert v_cmd(forward_distance=0.5, v_ego=5.0, v_lead=0.0) == 0.0


def test_accelerates_when_gap_exceeds_target():
    assert v_cmd(gap=states.FOLLOW_TARGET_DISTANCE_M + 3.0, v_ego=5.0, v_lead=5.0) > 5.0


def test_relative_velocity_damping_slows_ego_when_closing():
    """Same gap, ego faster than leader -> command below the leader speed."""
    closing = v_cmd(gap=states.FOLLOW_TARGET_DISTANCE_M, v_ego=8.0, v_lead=5.0)
    assert closing < 5.0


def test_clipped_to_vehicle_v_max():
    assert v_cmd(gap=50.0, v_ego=9.0, v_lead=9.0) == pytest.approx(states.VEHICLE_V_MAX / 3.6)


def test_wide_corridor_targets_d0_and_closes_the_gap_faster():
    """min_forward_overtake_width >= MIN_OVERTAKE_WIDTH_M -> target distance is D0_M."""
    gap = 3.0
    narrow = v_cmd(gap=gap, overtake_width=states.MIN_OVERTAKE_WIDTH_M - 0.1)
    wide = v_cmd(gap=gap, overtake_width=states.MIN_OVERTAKE_WIDTH_M)

    assert wide > narrow
    assert narrow == pytest.approx(5.0 + states.FOLLOW_K_GAP * (gap - states.FOLLOW_TARGET_DISTANCE_M))
    assert wide == pytest.approx(5.0 + states.FOLLOW_K_GAP * (gap - states.D0_M))


def test_no_leader_returns_vehicle_v_max_in_mps():
    """Regression guard: this branch used to return km/h among m/s returns."""
    assert v_cmd(forward_distance=None) == pytest.approx(states.VEHICLE_V_MAX / 3.6)


def test_gains_are_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.FOLLOW_K_GAP
    gap = states.FOLLOW_TARGET_DISTANCE_M + 1.0
    try:
        states.FOLLOW_K_GAP = 0.0
        assert v_cmd(gap=gap) == pytest.approx(5.0)
        states.FOLLOW_K_GAP = 2.0
        assert v_cmd(gap=gap) == pytest.approx(7.0)
    finally:
        states.FOLLOW_K_GAP = original
