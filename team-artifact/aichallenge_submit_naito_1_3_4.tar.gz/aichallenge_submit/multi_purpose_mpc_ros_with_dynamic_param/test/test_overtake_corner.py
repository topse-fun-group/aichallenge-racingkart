"""Unit tests for corner overtaking (pure Python, no rclpy).

Covers the corner-specific follow -> overtake trigger, the commit period that
keeps OvertakeState alive, and the has_future_width equal-width fix.
"""

import re

import numpy as np
import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import (
    FollowState,
    OvertakeState,
    StateContext,
)

# A curvature comfortably past the corner threshold, and one comfortably inside it.
CORNER_KAPPA = 3.0 * states.OVERTAKE_CORNER_KAPPA
STRAIGHT_KAPPA = 0.1 * states.OVERTAKE_CORNER_KAPPA

WIDE = states.MIN_OVERTAKE_WIDTH_M + 0.5
NARROW = states.MIN_OVERTAKE_WIDTH_M - 0.5


def make_ctx(
    *,
    t=0.0,
    kappa=CORNER_KAPPA,
    left=WIDE,
    right=NARROW,
    distance=None,
    v_ego=8.0,
    v_lead=8.0,
    side_vehicle=False,
    left_side=False,
    right_side=False,
    is_colliding=False,
    e_y=0.0,
    offset=1.5,
    lf=None,
    rf=None,
    tight=False,
):
    """A follow-state context sitting behind a leader in a corner.

    offset != 0 means a vehicle is detected (the corridor returns 0 otherwise),
    and the future widths default to the current ones so cases that do not care
    about prediction behave as before.
    """
    if distance is None:
        distance = states.OVERTAKE_CORNER_MAX_DIST_M - 1.0
    if lf is None:
        lf = left
    if rf is None:
        rf = right
    return StateContext(
        current_time_sec=t,
        dt=0.025,
        state_id="ego",
        pose_x=0.0,
        pose_y=0.0,
        pose_theta=0.0,
        velocity=v_ego,
        is_colliding=is_colliding,
        path_psi=0.0,
        path_e_y=e_y,
        path_kappa=kappa,
        forward_vehicle_distance=distance,
        forward_vehicle_speed=v_lead,
        closest_forward_vehicle_speed=v_lead,
        overtake_width_left=left,
        overtake_width_right=right,
        overtake_width_left_future=lf,
        overtake_width_right_future=rf,
        target_overtake_offset=offset,
        min_forward_overtake_width=max(left, right),
        has_side_vehicle=side_vehicle,
        has_left_side_vehicle=left_side,
        has_right_side_vehicle=right_side,
        in_tight_corner=tight,
    )


def follow_decision(**kwargs):
    return FollowState().check_transition(make_ctx(**kwargs))


def follow_reason(**kwargs):
    """Return the reason string of the block that fired, or None.

    Several entry blocks coexist, so asserting on the return value alone cannot
    tell which one fired.
    """
    msgs = []
    ctx = make_ctx(**kwargs)
    ctx.log_event = msgs.append
    result = FollowState().check_transition(ctx)
    if result != "overtake" or not msgs:
        return None
    m = re.search(r"reason=(\S+)", msgs[-1])
    return m.group(1) if m else None


# --- corner trigger -------------------------------------------------------

FAST_LEAD = dict(v_ego=10.0,
                 v_lead=10.0 - (states.OVERTAKE_CORNER_SPEED_MARGIN_MPS + 1.0))


def test_does_not_dive_inside_in_a_left_corner():
    """kappa > 0 is a left corner, so the inside is the left side.

    The reference path is traj_mincurv, which already hugs the inside, so there
    is structurally no room there. Measured over 115 corner entries: inside won
    7% and aborted on width 76%; outside won 23% and aborted 26%.
    """
    assert follow_decision(kappa=+CORNER_KAPPA, left=WIDE, right=NARROW,
                           **FAST_LEAD) != "overtake"


def test_does_not_dive_inside_in_a_right_corner():
    assert follow_decision(kappa=-CORNER_KAPPA, left=NARROW, right=WIDE,
                           **FAST_LEAD) != "overtake"


def test_fires_on_the_outside_of_a_left_corner():
    """The outside is the side that keeps its width through the corner."""
    assert follow_decision(kappa=+CORNER_KAPPA, left=NARROW, right=WIDE,
                           **FAST_LEAD) == "overtake"


def test_fires_on_the_outside_of_a_right_corner():
    assert follow_decision(kappa=-CORNER_KAPPA, left=WIDE, right=NARROW,
                           **FAST_LEAD) == "overtake"


def test_the_inside_veto_does_not_apply_on_a_straight():
    """On a straight the sign of kappa is noise, so "inside" is meaningless.

    Measured: |kappa| < OVERTAKE_CORNER_KAPPA "inside" entries won 9 of 10.
    """
    assert follow_decision(kappa=+STRAIGHT_KAPPA, left=WIDE, right=NARROW,
                           **FAST_LEAD) == "overtake"
    assert follow_decision(kappa=-STRAIGHT_KAPPA, left=NARROW, right=WIDE,
                           **FAST_LEAD) == "overtake"


def test_the_corner_trigger_still_needs_a_speed_advantage():
    """Being on the outside is not on its own a reason to attack."""
    assert follow_decision(kappa=+CORNER_KAPPA, left=NARROW, right=WIDE) != "overtake"
    assert follow_decision(kappa=-CORNER_KAPPA, left=WIDE, right=NARROW) != "overtake"


def test_does_not_fire_when_the_leader_is_too_far_ahead():
    far = states.OVERTAKE_CORNER_MAX_DIST_M + 1.0
    assert follow_decision(distance=far) != "overtake"


def test_does_not_fire_while_losing_ground_to_the_leader():
    """Relative speed below the margin means we cannot close on the inside line."""
    assert follow_decision(v_ego=6.0, v_lead=8.0) != "overtake"


def test_does_not_fire_with_a_vehicle_alongside():
    assert follow_decision(left_side=True) != "overtake"
    assert follow_decision(right_side=True) != "overtake"


def test_collision_still_wins_over_the_corner_trigger():
    assert follow_decision(is_colliding=True) == "recovery"


def test_corner_thresholds_are_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.OVERTAKE_CORNER_KAPPA
    try:
        states.OVERTAKE_CORNER_KAPPA = 10.0  # nothing counts as a corner any more
        assert follow_decision(kappa=+CORNER_KAPPA) != "overtake"
    finally:
        states.OVERTAKE_CORNER_KAPPA = original


# --- has_future_width equal-width fix -------------------------------------

def test_equal_widths_no_longer_block_overtaking_forever():
    """if/elif with no else left has_future_width False whenever left == right."""
    state = FollowState()
    ctx = make_ctx(
        kappa=STRAIGHT_KAPPA,   # keep the corner trigger out of the way
        left=WIDE,
        right=WIDE,             # exactly equal
        v_ego=8.0,
        v_lead=1.0,             # slow leader so the safe block can fire
        # is_same_lane is kept in the safe block and has no deadband, so e_y must
        # match the chosen side: left == right makes is_left False, needing e_y < 0.
        e_y=-0.5,
    )
    assert state.check_transition(ctx) == "overtake"


# --- commit period --------------------------------------------------------

def overtaking_at(t):
    state = OvertakeState()
    state.on_enter(make_ctx(t=t))
    return state


def narrow_ctx(t):
    """A leader ahead with neither side wide enough — the abort condition."""
    return make_ctx(t=t, left=NARROW, right=NARROW, distance=4.0)


def test_narrow_road_does_not_abort_during_the_commit_period():
    state = overtaking_at(0.0)
    half = 0.5 * states.OVERTAKE_COMMIT_SEC
    assert state.check_transition(narrow_ctx(half)) is None


def test_narrow_road_aborts_once_the_commit_period_has_passed():
    state = overtaking_at(0.0)
    past = states.OVERTAKE_COMMIT_SEC + 0.1
    assert state.check_transition(narrow_ctx(past)) == "follow"


def test_losing_sight_of_everyone_does_not_end_the_pass_during_the_commit():
    """Shifting 1.5-2 m sideways drops the leader out of both detection windows."""
    state = overtaking_at(0.0)
    lost = make_ctx(t=0.5 * states.OVERTAKE_COMMIT_SEC, distance=None)
    lost.forward_vehicle_distance = None
    lost.forward_vehicle_speed = None
    assert state.check_transition(lost) is None


def test_losing_sight_ends_the_pass_after_the_commit():
    state = overtaking_at(0.0)
    lost = make_ctx(t=states.OVERTAKE_COMMIT_SEC + 0.1)
    lost.forward_vehicle_distance = None
    lost.forward_vehicle_speed = None
    assert state.check_transition(lost) == "follow_path"


def test_collision_aborts_even_inside_the_commit_period():
    state = overtaking_at(0.0)
    ctx = narrow_ctx(0.1)
    ctx.is_colliding = True
    assert state.check_transition(ctx) == "recovery"


def test_commit_period_is_read_from_module_globals_at_call_time():
    original = states.OVERTAKE_COMMIT_SEC
    try:
        states.OVERTAKE_COMMIT_SEC = 0.0
        state = overtaking_at(0.0)
        assert state.check_transition(narrow_ctx(0.1)) == "follow"
    finally:
        states.OVERTAKE_COMMIT_SEC = original


# --- 寄せ側の解決 (Pure Pursuit と状態機械で共有する単一の真実) --------------

def side_ctx(kappa, left, right, offset=1.5):
    return make_ctx(kappa=kappa, left=left, right=right, offset=offset)


def test_resolve_side_is_none_when_no_vehicle_is_detected():
    """_compute_v2x_overtake_corridor returns (0, 0, 0) with nothing around."""
    assert states.resolve_overtake_side(side_ctx(STRAIGHT_KAPPA, 0.0, 0.0, offset=0.0)) == "none"


# --- 中断が「実際に寄せている側」を見る -------------------------------------

def overtaking_on(side, t=0.0):
    """指定した側へ寄せる状態で OvertakeState に突入させる。"""
    kappa = +CORNER_KAPPA if side == "left" else -CORNER_KAPPA
    ctx = side_ctx(kappa, WIDE if side == "left" else NARROW,
                   NARROW if side == "left" else WIDE)
    ctx.current_time_sec = t
    state = OvertakeState()
    state.on_enter(ctx)
    assert state._overtake_side == side
    return state


def abort_ctx(t, left, right):
    ctx = make_ctx(t=t, left=left, right=right, distance=4.0)
    ctx.target_overtake_offset = 1.5
    return ctx


ABORT = states.OVERTAKE_ABORT_WIDTH_M
PAST = states.OVERTAKE_COMMIT_SEC + 0.1


def test_aborts_when_the_side_we_drive_into_closes_even_if_the_other_side_is_wide():
    """従来は max(left,right) を見ていたため、塞がった側へ突っ込み続けていた。"""
    state = overtaking_on("left")
    assert state.check_transition(abort_ctx(PAST, ABORT - 0.3, WIDE + 2.0)) == "follow"


def test_does_not_abort_when_our_side_stays_open_but_the_other_side_closes():
    state = overtaking_on("left")
    assert state.check_transition(abort_ctx(PAST, WIDE, 0.0)) is None


def test_width_between_the_abort_and_entry_thresholds_does_not_abort():
    """突入 2.6 / 中断 2.2 のヒステリシス帯。"""
    mid = 0.5 * (ABORT + states.MIN_OVERTAKE_WIDTH_M)
    assert ABORT < mid < states.MIN_OVERTAKE_WIDTH_M
    state = overtaking_on("left")
    assert state.check_transition(abort_ctx(PAST, mid, NARROW)) is None


def test_abort_threshold_is_read_from_module_globals_at_call_time():
    original = states.OVERTAKE_ABORT_WIDTH_M
    try:
        states.OVERTAKE_ABORT_WIDTH_M = WIDE + 1.0   # 何でも中断する
        state = overtaking_on("left")
        assert state.check_transition(abort_ctx(PAST, WIDE, NARROW)) == "follow"
    finally:
        states.OVERTAKE_ABORT_WIDTH_M = original


# --- corner overtake が前方全車の幅も見る -----------------------------------

def test_corner_trigger_respects_other_forward_vehicles():
    """inside_width は最近傍 1 台のコリドー。奥の車で塞がっていたら行かない。"""
    ctx = make_ctx(kappa=+CORNER_KAPPA, left=WIDE, right=NARROW)
    ctx.min_forward_overtake_width = NARROW      # 奥の車が塞いでいる
    assert FollowState().check_transition(ctx) != "overtake"


# --- 将来幅 (T 秒後の先行車位置でコリドーを引き直したもの) --------------------

def future_ctx(left, right, lf, rf, **kw):
    """現在幅 (left/right) と将来幅 (lf/rf) を別々に与える。"""
    return make_ctx(left=left, right=right, lf=lf, rf=rf, **kw)


def test_side_that_will_close_is_not_chosen():
    """今は左が広くても、1 秒後に閉じるなら左は選ばない。"""
    ctx = future_ctx(left=WIDE, right=NARROW, lf=0.0, rf=NARROW)
    assert states.resolve_overtake_side(ctx) == "right"


def test_side_that_is_blocked_now_is_not_chosen():
    """1 秒後に開く側でも、今塞がっているなら選ばない。

    中断判定は現在幅を見るので、将来幅だけで選ぶと突入直後に hard_narrow で
    弾かれる (実測 34 件中 9 件)。
    """
    ctx = future_ctx(left=0.0, right=NARROW, lf=WIDE + 2.0, rf=NARROW)
    assert states.resolve_overtake_side(ctx) == "right"


def test_side_no_longer_prefers_the_inside_in_a_corner():
    """ADR-031 の内側優先が消えていること。左コーナーでも内側が狭ければ右。"""
    ctx = future_ctx(left=NARROW, right=WIDE, lf=NARROW, rf=WIDE, kappa=+CORNER_KAPPA)
    assert states.resolve_overtake_side(ctx) == "right"


def test_side_is_none_without_a_detected_vehicle():
    ctx = future_ctx(left=0.0, right=0.0, lf=0.0, rf=0.0)
    ctx.target_overtake_offset = 0.0
    assert states.resolve_overtake_side(ctx) == "none"


# --- ハード中断 (コミット期間を貫通) ----------------------------------------

HARD = states.OVERTAKE_HARD_ABORT_WIDTH_M
MID_COMMIT = 0.5 * states.OVERTAKE_COMMIT_SEC


def committed_overtake_on(side):
    lf, rf = (WIDE, NARROW) if side == "left" else (NARROW, WIDE)
    state = OvertakeState()
    state.on_enter(future_ctx(left=WIDE, right=WIDE, lf=lf, rf=rf))
    assert state._overtake_side == side
    return state


def test_hard_abort_fires_inside_the_commit_period():
    """幅が崩壊したらコミット期間を無視して即中断する。"""
    state = committed_overtake_on("left")
    ctx = future_ctx(left=HARD - 0.3, right=WIDE, lf=HARD - 0.3, rf=WIDE,
                     t=MID_COMMIT, distance=4.0)
    assert state.check_transition(ctx) == "follow"


def test_soft_abort_still_waits_for_the_commit_period():
    """ハード閾値とソフト閾値の間はコミット中は維持する。"""
    mid = 0.5 * (HARD + states.OVERTAKE_ABORT_WIDTH_M)
    assert HARD < mid < states.OVERTAKE_ABORT_WIDTH_M
    state = committed_overtake_on("left")
    ctx = future_ctx(left=mid, right=WIDE, lf=mid, rf=WIDE, t=MID_COMMIT, distance=4.0)
    assert state.check_transition(ctx) is None

    late = future_ctx(left=mid, right=WIDE, lf=mid, rf=WIDE,
                      t=states.OVERTAKE_COMMIT_SEC + 0.1, distance=4.0)
    assert state.check_transition(late) == "follow"


def test_collision_still_wins_over_the_hard_abort():
    state = committed_overtake_on("left")
    ctx = future_ctx(left=0.0, right=WIDE, lf=0.0, rf=WIDE, t=0.1, distance=4.0,
                     is_colliding=True)
    assert state.check_transition(ctx) == "recovery"


def test_hard_abort_threshold_is_read_from_module_globals_at_call_time():
    original = states.OVERTAKE_HARD_ABORT_WIDTH_M
    try:
        states.OVERTAKE_HARD_ABORT_WIDTH_M = 0.0   # 何があっても発火しない
        state = committed_overtake_on("left")
        ctx = future_ctx(left=0.1, right=WIDE, lf=0.1, rf=WIDE, t=MID_COMMIT, distance=4.0)
        assert state.check_transition(ctx) is None
    finally:
        states.OVERTAKE_HARD_ABORT_WIDTH_M = original


# --- FollowState の将来幅ブロック -------------------------------------------

FAST = states.OVERTAKE_CORNER_SPEED_MARGIN_MPS + 1.0


def follow_future(left, right, lf, rf, dv=FAST):
    """Which block fired for this now/future width pair."""
    # 右コーナー (kappa < 0) にして、広い方の left が外側になるようにする。
    # このブロックの検証対象は将来幅であって内外判定ではない。
    return follow_reason(kappa=-CORNER_KAPPA, left=left, right=right, lf=lf, rf=rf,
                         v_ego=8.0, v_lead=8.0 - dv)


def test_future_block_fires_when_both_now_and_future_are_wide():
    assert follow_future(WIDE, NARROW, WIDE, NARROW) == "future_width_overtake"


def test_future_block_does_not_fire_when_the_gap_will_close():
    """本命の回帰防止: 今は入れるが 1 秒後に閉じるケース。"""
    assert follow_future(WIDE, NARROW, NARROW, NARROW) != "future_width_overtake"


def test_future_block_does_not_fire_when_it_is_not_open_yet():
    assert follow_future(NARROW, NARROW, WIDE, NARROW) != "future_width_overtake"


def test_future_block_needs_a_real_speed_advantage():
    slow = states.OVERTAKE_CORNER_SPEED_MARGIN_MPS - 0.5
    assert follow_future(WIDE, NARROW, WIDE, NARROW, dv=slow) != "future_width_overtake"


# --- 急カーブの速度上限 (回頭角 120 度未満のコーナー) ------------------------

def test_tight_corner_flag_defaults_to_off():
    """StateContext のデフォルトは「急カーブではない」。"""
    assert make_ctx().in_tight_corner is False


def test_corner_speed_cap_formula_matches_the_speed_profile():
    """v = sqrt(ay_max / |kappa|) は compute_speed_profile と同じ式。

    実装は mpc_controller 側 (rclpy 依存) なので、ここでは式と
    そこから出る上限値が意図どおりであることを固定する。
    """
    ay_max = 9.5           # OvertakeState.AY_MAX / FollowPathState 相当
    for kappa, expect_kmh in ((0.10, 35.1), (0.15, 28.6), (0.20, 24.8)):
        v = np.sqrt(ay_max / (abs(kappa) + 1e-6))
        assert v * 3.6 == pytest.approx(expect_kmh, abs=0.2)


# --- 経路相対の将来幅予測 ---------------------------------------------------

def predict(left, right, lead_speed, heading_deg):
    return states.predict_overtake_widths(
        left, right, lead_speed, np.deg2rad(heading_deg))


def test_leader_drifting_left_narrows_the_left_and_widens_the_right():
    lf, rf = predict(3.0, 3.0, 6.94, +10.0)
    assert lf < 3.0 < rf


def test_leader_drifting_right_narrows_the_right_and_widens_the_left():
    lf, rf = predict(3.0, 3.0, 6.94, -10.0)
    assert rf < 3.0 < lf


def test_leader_parallel_to_the_path_leaves_the_widths_unchanged():
    """sign(0) = 0 なので加速度項も消え、現在幅と一致する。"""
    lf, rf = predict(3.0, 2.0, 6.94, 0.0)
    assert (lf, rf) == pytest.approx((3.0, 2.0))


def test_a_stopped_leader_still_gets_the_acceleration_margin():
    T = states.OVERTAKE_PREDICT_HORIZON_SEC
    expected = 0.5 * states.OVERTAKE_PREDICT_LAT_ACCEL_MPSS * T * T
    base = expected + 1.0            # 0 クランプに当たらない幅から始める
    lf, rf = predict(base, base, 0.0, +10.0)
    assert base - lf == pytest.approx(expected)
    assert rf - base == pytest.approx(expected)


def test_widths_never_go_negative():
    lf, rf = predict(0.5, 3.0, 20.0, +45.0)
    assert lf == 0.0
    assert rf > 3.0


def test_displacement_matches_the_specified_formula():
    """d = v*sin(hd)*T + 0.5*A*T^2 (ご指定の式)。"""
    T = states.OVERTAKE_PREDICT_HORIZON_SEC
    A = states.OVERTAKE_PREDICT_LAT_ACCEL_MPSS
    d = 6.94 * np.sin(np.deg2rad(10.0)) * T + 0.5 * A * T * T
    base = d + 1.0                   # 0 クランプに当たらない幅から始める
    lf, rf = predict(base, base, 6.94, +10.0)
    assert base - lf == pytest.approx(d)
    assert rf - base == pytest.approx(d)


def test_prediction_flips_the_chosen_side():
    """将来幅が逆転する条件では resolve_overtake_side の答えも変わる。"""
    left, right = 3.4, 3.0
    lf, rf = predict(left, right, 6.94, +10.0)     # 左へ寄る -> 右が広くなる
    assert lf < rf
    ctx = future_ctx(left=left, right=right, lf=lf, rf=rf)
    assert states.resolve_overtake_side(ctx) == "right"


def test_lateral_accel_is_read_from_module_globals_at_call_time():
    original = states.OVERTAKE_PREDICT_LAT_ACCEL_MPSS
    try:
        states.OVERTAKE_PREDICT_LAT_ACCEL_MPSS = 0.0
        lf, _ = predict(3.0, 3.0, 6.94, +10.0)
        T = states.OVERTAKE_PREDICT_HORIZON_SEC
        assert 3.0 - lf == pytest.approx(6.94 * np.sin(np.deg2rad(10.0)) * T)
    finally:
        states.OVERTAKE_PREDICT_LAT_ACCEL_MPSS = original


# --- 直線 (予測を掛けない = 将来幅が現在幅と同じ) ---------------------------

def test_side_falls_back_to_the_wider_current_width_without_prediction():
    """直線では将来幅 = 現在幅。min(now, future) が min(now, now) に退化し、
    「現在幅が広い側」という安定した判定に戻る。"""
    assert states.resolve_overtake_side(
        future_ctx(left=WIDE, right=NARROW, lf=WIDE, rf=NARROW)) == "left"
    assert states.resolve_overtake_side(
        future_ctx(left=NARROW, right=WIDE, lf=NARROW, rf=WIDE)) == "right"


def test_side_is_deterministic_without_prediction():
    """予測を掛けなければノイズ源が無く、同じ入力で必ず同じ側になる。"""
    ctx = future_ctx(left=3.01, right=3.00, lf=3.01, rf=3.00)
    assert {states.resolve_overtake_side(ctx) for _ in range(20)} == {"left"}


def test_lateral_accel_term_no_longer_saturates_the_track_width():
    """0.5*A*T^2 がコース幅 (半幅 約3m) を超えると片側が必ず 0 に張り付き、
    寄せ側が sign(heading_diff) だけで決まってしまう。"""
    T = states.OVERTAKE_PREDICT_HORIZON_SEC
    acc_term = 0.5 * states.OVERTAKE_PREDICT_LAT_ACCEL_MPSS * T * T
    assert acc_term < 3.0



# --- コーナー内側の見送り (ヘルパ単体) --------------------------------------

def inside_flag(kappa, left, right, offset=1.5):
    return states.is_inside_corner_overtake(
        make_ctx(kappa=kappa, left=left, right=right, offset=offset))


def test_helper_flags_the_inside_of_each_corner():
    assert inside_flag(+CORNER_KAPPA, WIDE, NARROW) is True   # 左コーナー・左寄せ
    assert inside_flag(-CORNER_KAPPA, NARROW, WIDE) is True   # 右コーナー・右寄せ


def test_helper_clears_the_outside_of_each_corner():
    assert inside_flag(+CORNER_KAPPA, NARROW, WIDE) is False
    assert inside_flag(-CORNER_KAPPA, WIDE, NARROW) is False


def test_helper_never_flags_a_straight():
    for left, right in [(WIDE, NARROW), (NARROW, WIDE)]:
        assert inside_flag(+STRAIGHT_KAPPA, left, right) is False
        assert inside_flag(-STRAIGHT_KAPPA, left, right) is False


def test_helper_clears_when_no_vehicle_is_detected():
    """offset ~ 0 means resolve_overtake_side returns "none".

    Without the guard, "none" != "left" would read as "right" and spuriously
    veto every right-hand corner.
    """
    assert inside_flag(-CORNER_KAPPA, NARROW, WIDE, offset=0.0) is False
    assert inside_flag(+CORNER_KAPPA, WIDE, NARROW, offset=0.0) is False


def test_helper_follows_the_side_actually_driven_not_the_wider_now():
    """resolve_overtake_side scores min(now, future); the veto must agree with it.

    Left is wider now but closes, so the driven side is the right = the inside
    of this right-hand corner.
    """
    ctx = make_ctx(kappa=-CORNER_KAPPA, left=WIDE, right=NARROW,
                   lf=NARROW - 1.0, rf=NARROW)
    assert states.resolve_overtake_side(ctx) == "right"
    assert states.is_inside_corner_overtake(ctx) is True


def test_helper_reads_the_corner_threshold_from_module_globals():
    original = states.OVERTAKE_CORNER_KAPPA
    try:
        states.OVERTAKE_CORNER_KAPPA = 10.0  # nothing counts as a corner
        assert inside_flag(+CORNER_KAPPA, WIDE, NARROW) is False
    finally:
        states.OVERTAKE_CORNER_KAPPA = original


def test_follow_path_state_also_skips_the_inside():
    """Measured entries came from both states (follow 127 / follow_path 31)."""
    args = dict(left=WIDE, right=NARROW, v_ego=10.0, v_lead=0.0, distance=3.0)
    assert states.FollowPathState().check_transition(
        make_ctx(kappa=+CORNER_KAPPA, **args)) != "overtake"
    assert states.FollowPathState().check_transition(
        make_ctx(kappa=-CORNER_KAPPA, **args)) == "overtake"
