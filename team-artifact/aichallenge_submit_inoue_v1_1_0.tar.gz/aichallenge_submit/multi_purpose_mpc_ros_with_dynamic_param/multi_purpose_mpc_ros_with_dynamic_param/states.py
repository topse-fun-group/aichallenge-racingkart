#!/usr/bin/env python3
"""Driving state definitions for the State pattern.

Each concrete state defines:
  - MPC parameters (v_max, ay_max, Q, R, QN, etc.)
  - Transition conditions to other states
  - Optional control override (e.g., Recovery bypasses MPC)

Phase 1: FollowPath + Recovery
Phase 2: Follow + Overtake
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, List, Tuple
import numpy as np

class ControlMode(Enum):
    PURE_PURSUIT = auto()
    MPC = auto()
    OVERRIDE = auto()

try:
    from autoware_auto_vehicle_msgs.msg import GearCommand
    GEAR_DRIVE = GearCommand.DRIVE
    GEAR_REVERSE = GearCommand.REVERSE
except ImportError:
    GEAR_DRIVE = 2
    GEAR_REVERSE = 20

# ---------------------------------------------------------------------------
# Stuck detection constants (shared by all states)
# ---------------------------------------------------------------------------
STUCK_VELOCITY_THRESHOLD = 0.3  # [m/s] — below this is considered "stopped"
STUCK_DURATION = 2.0            # [s] — stopped 2.0s triggers recovery (prevents false trigger during launch)


# ---------------------------------------------------------------------------
# Data transfer objects
# ---------------------------------------------------------------------------

@dataclass
class MPCStateParams:
    """MPC parameters that each state provides."""
    v_max: float          # [km/h]
    ay_max: float         # [m/s^2]
    Q: List[float]        # [e_y, e_psi, t] — 3 elements
    R: List[float]        # [v, delta] — 2 elements
    QN: List[float]       # [e_y, e_psi, t] — 3 elements
    lateral_offset: float = 0.0  # [m] for overtake maneuver


@dataclass
class StateContext:
    """Snapshot of sensor / vehicle data consumed by state transition logic."""

    # --- Time ---------------------------------------------------------------
    current_time_sec: float   # ROS clock time [s]
    dt: float                 # time since last control loop [s]

    # --- Vehicle state ------------------------------------------------------
    pose_x: float             # [m]
    pose_y: float             # [m]
    pose_theta: float         # yaw [rad]
    velocity: float           # longitudinal speed [m/s]

    # --- Collision ----------------------------------------------------------
    is_colliding: bool
    time_since_collision: Optional[float] = None  # [s], None if no collision

    # --- Path ---------------------------------------------------------------
    path_deviation: float = 0.0  # lateral distance from reference path [m]
    path_psi: float = 0.0        # closest waypoint orientation [rad]
    path_e_y: float = 0.0        # signed lateral offset from path centerline [m]
    path_left_wall: float = 3.0  # true clearance from ref path to left track boundary [m]
    path_right_wall: float = 3.0 # true clearance from ref path to right track boundary [m]
    future_min_path_left_wall: float = 3.0  # min clearance to left track boundary over next 20m [m]
    future_min_path_right_wall: float = 3.0 # min clearance to right track boundary over next 20m [m]
    path_kappa: float = 0.0      # closest waypoint curvature [1/m]
    future_max_kappa: float = 0.0 # max curvature over next 15m [1/m]
    is_approaching_straight: bool = False # True if exiting corner into upcoming straight

    # --- V2X (Phase 2) ------------------------------------------------------
    forward_vehicle_distance: Optional[float] = None   # [m]
    forward_vehicle_speed: Optional[float] = None       # [m/s]
    forward_vehicle_heading_diff: float = 0.0          # absolute heading diff relative to path_psi [rad]
    forward_vehicle_x_rel: Optional[float] = None      # relative longitudinal position (+ is ahead, - is behind) [m]
    forward_vehicle_y_rel: Optional[float] = None      # relative lateral position (+ is left, - is right) [m]
    forward_vehicle_pred_y_rel: Optional[float] = None # predicted leader lateral position at time of passing [m]
    leader_e_y: Optional[float] = None                 # signed lateral position of leader relative to raceline (+ is left) [m]
    forward_vehicle_track_s: Optional[float] = None    # relative distance along raceline waypoints (+ is ahead, - is behind) [m]

    # --- LiDAR (Phase 2) ----------------------------------------------------
    overtake_width_left: float = 0.0   # available width on left [m]
    overtake_width_right: float = 0.0  # available width on right [m]
    lidar_forward_clearance: Optional[float] = None   # [m] from LiDAR forward cone
    lidar_range_clearance: Optional[float] = None     # [m] from LiDAR full range
    current_laps: int = 1                             # current race lap count

    # --- Stuck detection ----------------------------------------------------
    time_stopped_sec: float = 0.0  # duration velocity ≈ 0 [s]
    is_in_recovery_cooldown: bool = False  # True during cooldown after recovery / startup


def _get_effective_forward_distance(ctx: StateContext) -> Optional[float]:
    """Get the effective forward distance along the track ribbon using V2X."""
    if ctx.forward_vehicle_track_s is not None and ctx.forward_vehicle_track_s >= 0.0:
        return ctx.forward_vehicle_track_s
    return ctx.forward_vehicle_distance


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class DrivingState(ABC):
    """Base class for all driving states (State pattern)."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique name identifying this state."""
        ...

    @property
    def gear(self) -> int:
        """Gear command for this state (GEAR_DRIVE or GEAR_REVERSE)."""
        return GEAR_DRIVE

    @property
    def control_mode(self) -> ControlMode:
        """Control mode required by this state (PURE_PURSUIT, MPC, or OVERRIDE)."""
        return ControlMode.MPC

    @abstractmethod
    def get_params(self) -> MPCStateParams:
        """Return the MPC parameters for this state."""
        ...

    @abstractmethod
    def check_transition(self, ctx: StateContext) -> Optional[str]:
        """Return the name of the next state, or ``None`` to stay."""
        ...

    def compute_control_override(
        self, ctx: StateContext
    ) -> Optional[Tuple[float, float, float]]:
        """Override MPC control output if this state needs direct actuation.

        Returns
        -------
        (speed [m/s], steer [rad], acceleration [m/s^2]) or ``None``
        to use normal MPC output.
        """
        return None

    def on_enter(self, ctx: StateContext) -> None:
        """Called once when entering this state."""
        pass

    def on_exit(self, ctx: StateContext) -> None:
        """Called once when leaving this state."""
        pass


# ---------------------------------------------------------------------------
# Phase 1 states
# ---------------------------------------------------------------------------

class FollowPathState(DrivingState):
    """Normal path-following — no obstacles or vehicles ahead.

    Target speed: 35 km/h (~9.7 m/s)
    """

    # ---- hardcoded parameters -----------------------------------------------
    V_MAX = 35.0              # [km/h]
    AY_MAX = 9.5              # [m/s^2]
    Q = [1_000_000.0, 100_000_000.0, 850_000.0]
    R = [100_000.0, 100.0]  # R[1]=1000.0 を追加してステアリング微振動を抑止
    QN = [1_000_000.0, 1_000.0, 10_000.0]

    # ---- forward-vehicle detection thresholds -------------------------------
    VEHICLE_DETECT_DISTANCE = 16.0           # [m] (通常走行車両用: 物理制動・車線変更時間を考慮した安全検知)
    VEHICLE_DETECT_DISTANCE_STOPPED = 18.0   # [m] (停止・極低速車両用: 物理制動距離を考慮して早期検知)
    VEHICLE_WIDTH_WITH_MARGIN = 2.30 # vehicle width + safety margin [m]

    @property
    def name(self) -> str:
        return "follow_path"

    @property
    def control_mode(self) -> ControlMode:
        return ControlMode.PURE_PURSUIT

    def get_params(self) -> MPCStateParams:
        return MPCStateParams(
            v_max=self.V_MAX,
            ay_max=self.AY_MAX,
            Q=list(self.Q),
            R=list(self.R),
            QN=list(self.QN),
        )

    def check_transition(self, ctx: StateContext) -> Optional[str]:
        # Collision → Recovery (always immediate)
        if ctx.is_colliding:
            return "recovery"

        # Stuck detection: velocity near zero for too long → Recovery (unless in cooldown)
        if (not ctx.is_in_recovery_cooldown
                and ctx.time_stopped_sec >= STUCK_DURATION
                and ctx.velocity < STUCK_VELOCITY_THRESHOLD):
            return "recovery"

        # Phase 2: forward-vehicle / obstacle detection (V2X)
        eff_dist = _get_effective_forward_distance(ctx)

        # Leader speed status:
        # - Completely stopped / crashed obstacle: speed < 1.5 m/s (5.4 km/h)
        # - Recovering from wall / very slow: speed < 5.0 m/s (18 km/h)
        is_leader_stopped = (ctx.forward_vehicle_speed is not None and ctx.forward_vehicle_speed < 1.5)
        is_leader_recovering = (ctx.forward_vehicle_speed is not None and ctx.forward_vehicle_speed < 5.0)

        # Dynamic detection threshold: expand to 18m for stopped/crashed vehicles
        detect_dist = self.VEHICLE_DETECT_DISTANCE_STOPPED if is_leader_stopped else self.VEHICLE_DETECT_DISTANCE
        has_leader = (eff_dist is not None and 0.0 <= eff_dist < detect_dist)

        # Physical passable clearance check (Car width 1.15m + leader buffer 0.40m + wall buffer 0.45m = 2.00m)
        MIN_PASSABLE_CLEARANCE = 2.00
        can_pass_left = (ctx.overtake_width_left >= MIN_PASSABLE_CLEARANCE)
        can_pass_right = (ctx.overtake_width_right >= MIN_PASSABLE_CLEARANCE)
        has_basic_clearance = can_pass_left or can_pass_right
        has_wide_clearance = (ctx.overtake_width_left >= 2.60) or (ctx.overtake_width_right >= 2.60)

        is_hairpin = (abs(ctx.path_kappa) >= 0.070 or ctx.future_max_kappa >= 0.075)
        is_braking_zone = (ctx.future_max_kappa >= 0.055 and abs(ctx.path_kappa) < 0.040)
        is_straight = abs(ctx.path_kappa) < 0.040 and ctx.future_max_kappa < 0.045

        # 2. Check if we can directly overtake without following (blocked during recovery cooldown)
        if has_leader and not ctx.is_in_recovery_cooldown:
            if is_leader_stopped or is_leader_recovering:
                # Stopped / slow vehicle on track: bypass immediately anywhere if space exists
                can_overtake = has_basic_clearance
                min_speed_req = 0.0
            else:
                # Dynamic racing overtake mode: pass if clearance exists
                can_overtake = has_basic_clearance and (has_wide_clearance or not is_hairpin or is_straight)
                min_speed_req = 3.5

            # During race launch from standstill (velocity < 2.0 m/s):
            # Never deadlock into zero-speed follow state on starting grid!
            if ctx.velocity < 2.0 and is_leader_stopped:
                if can_overtake:
                    return "overtake"
                return None  # Launch and accelerate in follow_path!

            if can_overtake and ctx.velocity >= min_speed_req:
                return "overtake"
            else:
                return "follow"

        return None


class RecoveryState(DrivingState):
    """Recovery after collision: wait → back up → rejoin path.

    Sequence
    --------
    1. **wait** (``WAIT_DURATION`` seconds): full stop.
    2. **back**: reverse at gentle speed (gear=REVERSE) until path deviation is small enough
       or ``MAX_BACK_DURATION`` elapses.
    3. Transition to ``follow_path``.
    """

    WAIT_DURATION = 0.1          # [s] (停止待機 0.1秒)
    BACK_SPEED = -4.0            # [m/s] (力強い後退速度で確実に角から脱出)
    BACK_ACCEL = 5.0             # [m/s^2] (後退加速度)
    MIN_BACK_DURATION = 1.8      # [s] (確実に約4mバックして障害物・角から完全離脱)
    MAX_BACK_DURATION = 2.4      # [s] (最大後退時間)
    PATH_DEVIATION_THRESHOLD = 1.5  # [m] — threshold to rejoin

    def __init__(self) -> None:
        self._enter_time: Optional[float] = None
        self._phase: str = "wait"          # "wait" | "back"

    @property
    def name(self) -> str:
        return "recovery"

    @property
    def control_mode(self) -> ControlMode:
        return ControlMode.OVERRIDE

    @property
    def gear(self) -> int:
        if self._phase == "back":
            return GEAR_REVERSE
        return GEAR_DRIVE

    def get_params(self) -> MPCStateParams:
        # Use a slow / conservative preset while recovering
        return MPCStateParams(
            v_max=18.0,  # 5 m/s = 18 km/h
            ay_max=3.0,
            Q=[5_000_000.0, 100_000_000.0, 200_000.0],
            R=[100_000.0, 0.0],
            QN=[1_000_000.0, 1_000.0, 10_000.0],
        )

    # -- lifecycle -----------------------------------------------------------

    def on_enter(self, ctx: StateContext) -> None:
        self._enter_time = ctx.current_time_sec
        self._phase = "wait"

    def on_exit(self, ctx: StateContext) -> None:
        self._enter_time = None
        self._phase = "wait"

    # -- transitions ---------------------------------------------------------

    def check_transition(self, ctx: StateContext) -> Optional[str]:
        if self._enter_time is None:
            return None

        elapsed = ctx.current_time_sec - self._enter_time

        if self._phase == "wait":
            if elapsed >= self.WAIT_DURATION:
                self._phase = "back"
            return None  # stay in recovery while waiting

        # phase == "back"
        back_elapsed = elapsed - self.WAIT_DURATION

        # Must reverse for at least MIN_BACK_DURATION (1.8s) to clear corner obstruction
        if back_elapsed < self.MIN_BACK_DURATION:
            return None

        # 1. Reverse stuck detection: if hit a rear wall after full reverse attempt, switch to forward
        if back_elapsed >= 1.8 and abs(ctx.velocity) < 0.12:
            return "follow_path"

        # 2. Rejoin path once min back duration completed or max reached
        if back_elapsed >= self.MAX_BACK_DURATION or (ctx.path_deviation < self.PATH_DEVIATION_THRESHOLD and back_elapsed >= self.MIN_BACK_DURATION):
            return "follow_path"

        return None

    # -- control override ----------------------------------------------------

    def compute_control_override(
        self, ctx: StateContext
    ) -> Optional[Tuple[float, float, float]]:
        if self._phase == "wait":
            return (0.0, 0.0, 0.0)  # full stop

        # Steering while reversing: aggressively turn nose towards raceline center (+35 deg bias towards center)
        TARGET_ANGLE_OFFSET = np.deg2rad(35.0)
        if ctx.path_e_y >= 0:
            # Vehicle is to the left of the path -> point nose right (-35 deg relative to path)
            target_psi = ctx.path_psi - TARGET_ANGLE_OFFSET
        else:
            # Vehicle is to the right of the path -> point nose left (+35 deg relative to path)
            target_psi = ctx.path_psi + TARGET_ANGLE_OFFSET

        # Normalized yaw error [-pi, pi]
        psi_err = (ctx.pose_theta - target_psi + np.pi) % (2 * np.pi) - np.pi

        # P-control for reverse steering:
        # In Autoware, steer > 0 is CCW (Left). While reversing, Left steer rotates nose CW (Right).
        # Therefore, psi_err > 0 (nose too far CCW/Left) requires steer > 0 (+K_P * psi_err).
        K_P = 1.5
        steer_cmd = float(np.clip(K_P * psi_err, -0.55, 0.55))

        return (self.BACK_SPEED, steer_cmd, self.BACK_ACCEL)


# ---------------------------------------------------------------------------
# Phase 2 states
# ---------------------------------------------------------------------------

class FollowState(DrivingState):
    """Follow a leading vehicle — maintain safe distance (5.5m), match speed."""

    TARGET_FOLLOWING_DISTANCE = 5.5   # [m] (安全な追従車間目標)
    STOP_DISTANCE = 2.5               # [m] (完全停止・ブレーキ閾値)
    FOLLOWING_KP = 0.6                # speed adjustment gain

    # ---- MPC parameters (same cornering capability as FollowPathState) ------
    _V_MAX_DEFAULT = 35.0   # [km/h] — ceiling, actual v_max is dynamic
    AY_MAX = 9.5
    # Q[0]=e_y (lateral), Q[1]=e_psi (heading), Q[2]=t (speed tracking)
    # Same as FollowPathState to maintain identical corner-tracking ability
    Q = [1_000_000.0, 100_000_000.0, 850_000.0]
    # R[0]=v, R[1]=delta (steering) — R[1]=100 to allow full steering in corners
    R = [100_000.0, 100.0]
    QN = [1_000_000.0, 1_000.0, 10_000.0]

    VEHICLE_DETECT_DISTANCE = 16.0
    VEHICLE_DETECT_DISTANCE_STOPPED = 18.0
    VEHICLE_WIDTH_WITH_MARGIN = 2.20

    CLEAR_HYSTERESIS_SEC = 1.5  # Must remain clear for 1.5 seconds continuously before returning to follow_path

    def __init__(self) -> None:
        self._clear_start_time: Optional[float] = None

    @property
    def name(self) -> str:
        return "follow"

    @property
    def control_mode(self) -> ControlMode:
        return ControlMode.PURE_PURSUIT

    def get_params(self) -> MPCStateParams:
        return MPCStateParams(
            v_max=self._V_MAX_DEFAULT,
            ay_max=self.AY_MAX,
            Q=list(self.Q),
            R=list(self.R),
            QN=list(self.QN),
        )

    def check_transition(self, ctx: StateContext) -> Optional[str]:
        if ctx.is_colliding:
            return "recovery"

        eff_dist = _get_effective_forward_distance(ctx)

        # Physical passable clearance check (Car width 1.15m + leader buffer 0.40m + wall buffer 0.45m = 2.00m)
        MIN_PASSABLE_CLEARANCE = 2.00
        can_pass_left = (ctx.overtake_width_left >= MIN_PASSABLE_CLEARANCE)
        can_pass_right = (ctx.overtake_width_right >= MIN_PASSABLE_CLEARANCE)
        has_basic_clearance = can_pass_left or can_pass_right
        has_wide_clearance = (ctx.overtake_width_left >= 2.60) or (ctx.overtake_width_right >= 2.60)

        is_hairpin = (abs(ctx.path_kappa) >= 0.070 or ctx.future_max_kappa >= 0.075)
        is_braking_zone = (ctx.future_max_kappa >= 0.055 and abs(ctx.path_kappa) < 0.040)
        is_straight = abs(ctx.path_kappa) < 0.040 and ctx.future_max_kappa < 0.045

        # Leader speed status:
        # - Completely stopped / crashed obstacle: speed < 1.5 m/s (5.4 km/h)
        # - Recovering from wall / very slow: speed < 5.0 m/s (18 km/h)
        is_leader_stopped = (ctx.forward_vehicle_speed is not None and ctx.forward_vehicle_speed < 1.5)
        is_leader_recovering = (ctx.forward_vehicle_speed is not None and ctx.forward_vehicle_speed < 5.0)

        if is_leader_stopped or is_leader_recovering:
            # Stopped / slow vehicle: bypass immediately anywhere on track if space exists
            can_overtake = has_basic_clearance
            min_speed_req = 0.0
        else:
            # Dynamic racing overtake mode: pass if clearance exists
            can_overtake = has_basic_clearance and (has_wide_clearance or not is_hairpin or is_straight)
            min_speed_req = 3.5

        # 1. Switch to Overtake when clearance is open (immediately evade and steer into open lane!)
        if can_overtake and ctx.velocity >= min_speed_req:
            self._clear_start_time = None
            return "overtake"

        # 2. Check if clearance is completely clear ahead
        detect_dist = self.VEHICLE_DETECT_DISTANCE_STOPPED if is_leader_stopped else self.VEHICLE_DETECT_DISTANCE
        has_v2x_leader = (ctx.forward_vehicle_distance is not None and 0.0 <= ctx.forward_vehicle_distance < detect_dist)
        is_forward_clear = (not has_v2x_leader and (ctx.lidar_forward_clearance is None or ctx.lidar_forward_clearance >= 5.0))
        if is_forward_clear:
            if self._clear_start_time is None:
                self._clear_start_time = ctx.current_time_sec
            elapsed_clear = ctx.current_time_sec - self._clear_start_time
            if elapsed_clear >= 1.5:
                self._clear_start_time = None
                return "follow_path"
        else:
            self._clear_start_time = None

        # Stuck detection: ONLY trigger Recovery if NOT intentionally waiting behind a leader/obstacle
        is_waiting_behind_leader = (eff_dist is not None and eff_dist < 10.0 and not has_basic_clearance)
        if not is_waiting_behind_leader:
            if (not ctx.is_in_recovery_cooldown
                    and ctx.time_stopped_sec >= STUCK_DURATION
                    and ctx.velocity < STUCK_VELOCITY_THRESHOLD):
                return "recovery"

        return None

    # -- dynamic v_max -------------------------------------------------------

    def get_adjusted_v_max_kmh(self, ctx: StateContext) -> float:
        """Compute dynamic v_max [km/h] to maintain steady following without excessive braking."""
        eff_dist = _get_effective_forward_distance(ctx)
        if eff_dist is None:
            return self._V_MAX_DEFAULT

        fwd_speed = ctx.forward_vehicle_speed if ctx.forward_vehicle_speed is not None else 6.0
        ego_speed = ctx.velocity
        rel_speed = ego_speed - fwd_speed  # > 0 means ego is closing in on leader

        if eff_dist <= self.STOP_DISTANCE:
            # Emergency stop only when critically close (< 1.8m)
            target_mps = 0.0
        elif eff_dist < 3.5:
            # Dangerously close zone (< 3.5m): strongly brake below leader speed to rapidly restore safe gap!
            target_mps = max(0.0, fwd_speed - 2.5)
        elif eff_dist < self.TARGET_FOLLOWING_DISTANCE:
            # Close following zone (3.5m - 5.5m):
            dist_factor = float(np.clip((eff_dist - 3.5) / (self.TARGET_FOLLOWING_DISTANCE - 3.5), 0.0, 1.0))
            if rel_speed <= 0.3:
                target_mps = max(0.0, fwd_speed * (0.80 + 0.20 * dist_factor))
            else:
                target_mps = max(0.0, fwd_speed * (0.60 + 0.30 * dist_factor) - 0.5 * rel_speed)
        else:
            # Normal following zone (>= 5.5m): smoothly approach leader
            distance_error = eff_dist - self.TARGET_FOLLOWING_DISTANCE
            target_mps = fwd_speed + self.FOLLOWING_KP * distance_error

        target_kmh = target_mps * 3.6
        return float(np.clip(target_kmh, 0.0, self._V_MAX_DEFAULT))


class OvertakeState(DrivingState):
    """Constant offset parallel attack mode: maintain high exit speed and rocket-pass on straight."""

    LATERAL_OFFSET = 1.30        # [m] (安全な並走オフセット幅)
    MIN_OVERTAKE_DURATION = 2.0  # [s] (最低2.0秒間はレーンをキープしチャタリング離脱を防止)
    MAX_OVERTAKE_DURATION = 6.0  # [s] (最大6.0秒で安全に通常ラインへ復帰・リセット)

    # ---- hardcoded parameters (38 km/h: フル加速で抜き去る) -----------------
    V_MAX_NORMAL = 35.0       # [km/h] normal overtake speed
    V_MAX_BOOST = 40.0        # [km/h] Push-to-Pass / DRS speed (unlocked at lap >= 5)
    AY_MAX = 9.5
    Q = [1_000_000.0, 100_000_000.0, 850_000.0]
    R = [100_000.0, 100.0]
    QN = [1_000_000.0, 1_000.0, 10_000.0]

    VEHICLE_DETECT_DISTANCE = 10.0

    def __init__(self) -> None:
        self._overtake_side: str = "right"  # Default to open right side
        self._enter_time: Optional[float] = None
        self._last_side_switch_time: Optional[float] = None
        self._calculated_offset: float = -0.95
        self._is_boost: bool = False

    @property
    def name(self) -> str:
        return "overtake"

    @property
    def control_mode(self) -> ControlMode:
        return ControlMode.PURE_PURSUIT

    def get_params(self) -> MPCStateParams:
        v_max = self.V_MAX_BOOST if self._is_boost else self.V_MAX_NORMAL
        return MPCStateParams(
            v_max=v_max,
            ay_max=self.AY_MAX,
            Q=list(self.Q),
            R=list(self.R),
            QN=list(self.QN),
            lateral_offset=self._calculated_offset,
        )

    def on_enter(self, ctx: StateContext) -> None:
        self._enter_time = ctx.current_time_sec
        self._last_side_switch_time = ctx.current_time_sec
        left_space = ctx.overtake_width_left
        right_space = ctx.overtake_width_right

        # Push-to-Pass (DRS): unlocked only when current_laps >= 5
        self._is_boost = (ctx.current_laps >= 5)
        v_max = self.V_MAX_BOOST if self._is_boost else self.V_MAX_NORMAL

        # 1. Minimum Wall Clearance Guarantee over the entire overtake horizon (min future wall clearance):
        WALL_SAFETY_MARGIN = 0.90  # [m] (Car half-width 0.58m + 0.32m physical buffer)
        MAX_OVERTAKE_OFFSET = 1.80  # [m] Maximum allowable lane offset to ensure stable path recovery

        # Evaluate safe offset using the minimum corridor width over the forward 20m:
        effective_path_left = min(ctx.path_left_wall, ctx.future_min_path_left_wall)
        effective_path_right = min(ctx.path_right_wall, ctx.future_min_path_right_wall)

        # Max safe offset relative to reference path without violating left/right track borders:
        max_safe_offset_left = min(MAX_OVERTAKE_OFFSET, max(0.0, effective_path_left - WALL_SAFETY_MARGIN))
        max_safe_offset_right = min(MAX_OVERTAKE_OFFSET, max(0.0, effective_path_right - WALL_SAFETY_MARGIN))

        # 2. Strict physical clearance side selection with Leader Position Gap Guarantee:
        MIN_PASSABLE_CLEARANCE = 2.00
        can_pass_left = (left_space >= MIN_PASSABLE_CLEARANCE and max_safe_offset_left >= 0.60)
        can_pass_right = (right_space >= MIN_PASSABLE_CLEARANCE and max_safe_offset_right >= 0.60)

        # CRITICAL: Check achievable lateral clearance relative to leader's actual position (lead_ey)
        lead_ey = ctx.leader_e_y
        if lead_ey is not None:
            # Passing on left requires achievable gap >= 1.45m between leader and ego
            can_pass_left = can_pass_left and (max_safe_offset_left - lead_ey >= 1.45)
            # Passing on right requires achievable gap >= 1.45m between leader and ego
            can_pass_right = can_pass_right and (lead_ey - (-max_safe_offset_right) >= 1.45)

        # Prioritize the side with the widest physical clearance around the obstacle/leader:
        if can_pass_left and can_pass_right:
            if right_space >= left_space + 0.40:
                self._overtake_side = "right"
            elif left_space >= right_space + 0.40:
                self._overtake_side = "left"
            else:
                self._overtake_side = "right" if max_safe_offset_right >= max_safe_offset_left else "left"
        elif can_pass_right:
            self._overtake_side = "right"
        elif can_pass_left:
            self._overtake_side = "left"
        else:
            self._overtake_side = "right" if right_space >= left_space else "left"

        # Dual-Vehicle Rectangle Bounding Box Clearance Model (using along-track progression):
        # Guarantees ego's front corners and lead's rear corners never clip in curves or straights
        s_rel = ctx.forward_vehicle_track_s if ctx.forward_vehicle_track_s is not None else ctx.forward_vehicle_x_rel
        if s_rel is not None:
            if s_rel > 6.0:
                gap_expansion = 0.0
            elif s_rel >= 1.5:
                # Approach phase: expand gap from 1.60m to 1.75m well before reaching rear bumper
                gap_expansion = float((6.0 - s_rel) / 4.5 * 0.15)
            elif s_rel >= -2.0:
                # Alongside phase: maintain full 1.75m lateral buffer until ego front clears lead front
                gap_expansion = 0.15
            else:
                # Pass complete phase: taper back down
                gap_expansion = float(np.clip((4.0 + s_rel) / 2.0 * 0.15, 0.0, 0.15))
        else:
            gap_expansion = 0.10

        effective_gap = 1.60 + gap_expansion
        STANDARD_OFFSET = 1.65 + gap_expansion
        lead_ey = ctx.leader_e_y

        if lead_ey is not None:
            if self._overtake_side == "left":
                target_off = max(STANDARD_OFFSET, lead_ey + effective_gap)
                self._calculated_offset = float(np.clip(target_off, 0.40, max_safe_offset_left))
            else:
                target_off = min(-STANDARD_OFFSET, lead_ey - effective_gap)
                self._calculated_offset = float(np.clip(target_off, -max_safe_offset_right, -0.40))
        else:
            if self._overtake_side == "left":
                self._calculated_offset = float(np.clip(STANDARD_OFFSET, 0.40, max_safe_offset_left))
            else:
                self._calculated_offset = float(np.clip(-STANDARD_OFFSET, -max_safe_offset_right, -0.40))

        lead_ey_str = f"{lead_ey:+.2f}m" if lead_ey is not None else "None"
        print(f"[Overtake Dynamic] Lap {ctx.current_laps}: kappa={ctx.path_kappa:+.3f}, "
              f"Lead(dist={ctx.forward_vehicle_distance}, ey={lead_ey_str}), "
              f"Clearance(L={left_space:.2f}m, R={right_space:.2f}m), "
              f"PathWall(L={ctx.path_left_wall:.2f}m/min{ctx.future_min_path_left_wall:.2f}m, R={ctx.path_right_wall:.2f}m/min{ctx.future_min_path_right_wall:.2f}m) -> "
              f"Chose: {self._overtake_side} (offset: {self._calculated_offset:+.2f}m, gap={effective_gap:.2f}m)", flush=True)

    def update_dynamic_offset(self, ctx: StateContext) -> float:
        """Dynamically adapt offset in real-time based on leader's continuous motion!"""
        left_space = ctx.overtake_width_left
        right_space = ctx.overtake_width_right

        WALL_SAFETY_MARGIN = 0.90  # [m]
        MAX_OVERTAKE_OFFSET = 1.80  # [m]
        effective_path_left = min(ctx.path_left_wall, ctx.future_min_path_left_wall)
        effective_path_right = min(ctx.path_right_wall, ctx.future_min_path_right_wall)
        max_safe_offset_left = min(MAX_OVERTAKE_OFFSET, max(0.0, effective_path_left - WALL_SAFETY_MARGIN))
        max_safe_offset_right = min(MAX_OVERTAKE_OFFSET, max(0.0, effective_path_right - WALL_SAFETY_MARGIN))

        # Strict Fail-Safe Dynamic Side Switching:
        # 1. ONLY allow side switching on straights (abs(kappa) < 0.040 and future_max_kappa < 0.045) to prevent instability in curves!
        # 2. Require cooldown of at least 2.0s between switches to completely eliminate chattering!
        # 3. CRUCIAL: NEVER switch sides when in close proximity (s_rel <= 5.5m) to avoid cross-cutting the leader's path!
        # 4. Only switch when current side is constricted (< 2.00m) while other side has ample passing space (>= 2.50m).
        s_rel = ctx.forward_vehicle_track_s if ctx.forward_vehicle_track_s is not None else ctx.forward_vehicle_x_rel
        is_straight = abs(ctx.path_kappa) < 0.040 and ctx.future_max_kappa < 0.045
        time_since_switch = (ctx.current_time_sec - self._last_side_switch_time) if self._last_side_switch_time is not None else 999.0
        is_safe_longitudinal_dist = (s_rel is not None and s_rel > 5.5)

        if is_straight and time_since_switch >= 2.0 and is_safe_longitudinal_dist:
            MIN_PASSABLE_CLEARANCE = 2.00
            if self._overtake_side == "left":
                should_switch_to_right = (
                    right_space >= 2.50 and max_safe_offset_right >= 0.80
                    and (left_space < MIN_PASSABLE_CLEARANCE or right_space > left_space + 1.20)
                )
                if should_switch_to_right:
                    print(f"[Overtake Dynamic] Straight dynamic side switch: LEFT -> RIGHT (left space {left_space:.2f}m vs right space {right_space:.2f}m, dist {s_rel:.2f}m)", flush=True)
                    self._overtake_side = "right"
                    self._last_side_switch_time = ctx.current_time_sec
            elif self._overtake_side == "right":
                should_switch_to_left = (
                    left_space >= 2.50 and max_safe_offset_left >= 0.80
                    and (right_space < MIN_PASSABLE_CLEARANCE or left_space > right_space + 1.20)
                )
                if should_switch_to_left:
                    print(f"[Overtake Dynamic] Straight dynamic side switch: RIGHT -> LEFT (right space {right_space:.2f}m vs left space {left_space:.2f}m, dist {s_rel:.2f}m)", flush=True)
                    self._overtake_side = "left"
                    self._last_side_switch_time = ctx.current_time_sec

        # Leader's current lateral offset from raceline (Frenet frame):
        lead_ey = ctx.leader_e_y
        if lead_ey is None and ctx.forward_vehicle_y_rel is not None:
            lead_ey = ctx.path_e_y + ctx.forward_vehicle_y_rel

        # Dual-Vehicle Rectangle Bounding Box Clearance Model:
        if s_rel is not None:
            if s_rel > 6.0:
                gap_expansion = 0.0
            elif s_rel >= 1.5:
                gap_expansion = float((6.0 - s_rel) / 4.5 * 0.15)
            elif s_rel >= -2.0:
                gap_expansion = 0.15
            else:
                gap_expansion = float(np.clip((4.0 + s_rel) / 2.0 * 0.15, 0.0, 0.15))
        else:
            gap_expansion = 0.10

        effective_gap = 1.60 + gap_expansion
        STANDARD_OFFSET = 1.65 + gap_expansion

        # Continuous leader motion tracking & dynamic 2-stage side-stepping:
        if lead_ey is not None:
            if self._overtake_side == "left":
                target_offset = max(STANDARD_OFFSET, lead_ey + effective_gap)
                self._calculated_offset = float(np.clip(target_offset, 0.40, max_safe_offset_left))
            else:
                target_offset = min(-STANDARD_OFFSET, lead_ey - effective_gap)
                self._calculated_offset = float(np.clip(target_offset, -max_safe_offset_right, -0.40))
        else:
            if self._overtake_side == "left":
                self._calculated_offset = float(np.clip(STANDARD_OFFSET, 0.40, max_safe_offset_left))
            else:
                self._calculated_offset = float(np.clip(-STANDARD_OFFSET, -max_safe_offset_right, -0.40))

        return self._calculated_offset

    def on_exit(self, ctx: StateContext) -> None:
        # Full reset on exit (whether successfully overtaken or failed/aborted)
        self._enter_time = None
        self._is_boost = False

    def check_transition(self, ctx: StateContext) -> Optional[str]:
        if ctx.is_colliding:
            return "recovery"

        # Stuck detection
        if (not ctx.is_in_recovery_cooldown
                and ctx.time_stopped_sec >= STUCK_DURATION
                and ctx.velocity < STUCK_VELOCITY_THRESHOLD):
            return "recovery"

        # Check longitudinal relative position using Waypoints along track (s_rel < 0 means ego is ahead of other car along track)
        s_rel = ctx.forward_vehicle_track_s if ctx.forward_vehicle_track_s is not None else ctx.forward_vehicle_x_rel

        # 1. Minimum duration lock: stay committed to overtake lane for at least MIN_OVERTAKE_DURATION (2.0s)
        if self._enter_time is not None:
            elapsed = ctx.current_time_sec - self._enter_time
            if elapsed < self.MIN_OVERTAKE_DURATION:
                return None

        # Check if approaching a high-speed braking zone before a sharp corner
        # Avoid cutting across raceline directly in pre-corner braking zones
        is_braking_zone = (ctx.future_max_kappa >= 0.055 and abs(ctx.path_kappa) < 0.040)

        # 2. Successfully overtaken: Leader is comfortably behind us along track (s_rel <= -6.5m / ~8 waypoints) -> smoothly return to raceline
        # In braking zones, hold the shifted line through turn-in to avoid clipping leader's nose
        if s_rel is not None and s_rel <= -6.5:
            if not is_braking_zone:
                return "follow_path"

        # 3. If leader has pulled far ahead along track (> 18.0m)
        if s_rel is not None and s_rel > 18.0:
            return "follow_path"

        # 4. Timeout handling:
        if self._enter_time is not None:
            elapsed = ctx.current_time_sec - self._enter_time
            # While currently side-by-side / overlapping along track (-5.5m <= s_rel <= 5.5m), NEVER abort! Maintain full acceleration!
            is_side_by_side = (s_rel is not None and -5.5 <= s_rel <= 5.5)
            if elapsed >= self.MAX_OVERTAKE_DURATION and not is_side_by_side and not is_braking_zone:
                return "follow_path"
            if elapsed >= 9.0 and not is_side_by_side:  # Absolute failsafe timeout (never cut into adjacent car)
                return "follow_path"

        return None
