#!/usr/bin/env python3

import yaml
from typing import List, Tuple, Optional, NamedTuple
import dataclasses
from scipy import sparse
from scipy.sparse import dia_matrix
import numpy as np
import copy
import os
import shutil
from datetime import datetime

# ROS 2
import rclpy
from rclpy.node import Node
from ament_index_python.packages import get_package_share_directory
from rclpy.parameter import Parameter
from visualization_msgs.msg import Marker, MarkerArray
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy

from std_msgs.msg import Empty, Bool, Float32MultiArray, Int32
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Pose2D, Point, Vector3
from std_msgs.msg import ColorRGBA

from rcl_interfaces.msg import SetParametersResult
from rclpy.parameter import Parameter

# autoware
from autoware_auto_control_msgs.msg import AckermannControlCommand
try:
    from autoware_auto_vehicle_msgs.msg import GearCommand
    HAS_GEAR_MSG = True
except ImportError:
    GearCommand = None
    HAS_GEAR_MSG = False
from autoware_auto_planning_msgs.msg import Trajectory
from v2x_msgs.msg import V2XVehiclePositionArray
from multi_purpose_mpc_ros_with_dynamic_param.v2x_vehicle_tracker import (
    V2XVehicleTracker,
    predictions_to_obstacles,
)

# Multi_Purpose_MPC
from multi_purpose_mpc_ros_with_dynamic_param.core.map import Map, Obstacle
from multi_purpose_mpc_ros_with_dynamic_param.core.reference_path import ReferencePath
from multi_purpose_mpc_ros_with_dynamic_param.core.spatial_bicycle_models import BicycleModel
from multi_purpose_mpc_ros_with_dynamic_param.core.MPC import MPC
from multi_purpose_mpc_ros_with_dynamic_param.core.utils import load_waypoints, kmh_to_m_per_sec, load_ref_path

# Project
from multi_purpose_mpc_ros_with_dynamic_param.common import convert_to_namedtuple, file_exists
from multi_purpose_mpc_ros_with_dynamic_param.simulation_logger import SimulationLogger
from multi_purpose_mpc_ros_with_dynamic_param.obstacle_manager import ObstacleManager
from multi_purpose_mpc_ros_with_dynamic_param.exexution_stats import ExecutionStats
from multi_purpose_mpc_ros_msgs.msg import AckermannControlBoostCommand, PathConstraints, BorderCells
from multi_purpose_mpc_ros_with_dynamic_param.tools.reference_velocity_configulator import ReferenceVelocityConfigulator

# State machine
from multi_purpose_mpc_ros_with_dynamic_param.states import StateContext, MPCStateParams, FollowState, OvertakeState, ControlMode
from multi_purpose_mpc_ros_with_dynamic_param.state_manager import StateManager
from multi_purpose_mpc_ros_with_dynamic_param.lidar_processor import LidarProcessor


RED = ColorRGBA(r=1.0, g=0.0, b=0.0, a=1.0)
YELLOW = ColorRGBA(r=1.0, g=1.0, b=0.0, a=1.0)
CYAN = ColorRGBA(r=0.0, g=156.0 / 255.0, b=209.0 / 255.0, a=1.0)

def array_to_ackermann_control_command(stamp, u: np.ndarray, acc: float) -> AckermannControlCommand:
    msg = AckermannControlCommand()
    msg.stamp = stamp
    msg.lateral.stamp = stamp
    msg.lateral.steering_tire_angle = u[1]
    msg.lateral.steering_tire_rotation_rate = 2.0
    msg.longitudinal.stamp = stamp
    msg.longitudinal.speed = u[0]
    msg.longitudinal.acceleration = acc
    return msg

def yaw_from_quaternion(q: Quaternion):
    sqx = q.x * q.x
    sqy = q.y * q.y
    sqz = q.z * q.z
    sqw = q.w * q.w

    # Cases derived from https://orbitalstation.wordpress.com/tag/quaternion/
    sarg = -2 * (q.x*q.z - q.w*q.y) / (sqx + sqy + sqz + sqw) # normalization added from urdfom_headers

    if sarg <= -0.99999:
        yaw = -2. * np.arctan2(q.y, q.x)
    elif sarg >= 0.99999:
        yaw = 2. * np.arctan2(q.y, q.x)
    else:
        yaw = np.arctan2(2. * (q.x*q.y + q.w*q.z), sqw + sqx - sqy - sqz)

    return yaw

def odom_to_pose_2d(odom: Odometry) -> Pose2D:
    pose = Pose2D()
    pose.x = odom.pose.pose.position.x
    pose.y = odom.pose.pose.position.y
    pose.theta = yaw_from_quaternion(odom.pose.pose.orientation)

    return pose

@dataclasses.dataclass
class MPCConfig:
    N: int
    Q: dia_matrix
    R: dia_matrix
    QN: dia_matrix
    v_max: float
    a_min: float
    a_max: float
    ay_max: float
    delta_max: float
    steer_rate_max: float
    control_rate: float
    steering_tire_angle_gain_var: float
    accel_low_pass_gain: float
    steer_low_pass_gain: float
    wp_id_offset: int
    use_max_kappa_pred: bool


class MPCController(Node):

    try:
        PKG_PATH: str = get_package_share_directory('multi_purpose_mpc_ros_with_dynamic_param') + "/"
    except Exception:
        PKG_PATH: str = get_package_share_directory('multi_purpose_mpc_ros') + "/"
    # MAX_LAPS = 6
    MAX_LAPS = 10000
    BUG_VEL = 40.0 # km/h
    BUG_ACC = 400.0

    SHOW_PLOT_ANIMATION = False
    PLOT_RESULTS = False
    ANIMATION_INTERVAL = 20

    KP = 100.0

    def __init__(self, config_path: str, ref_vel_config_path: Optional[str]) -> None:
        super().__init__("mpc_controller") # type: ignore

        # declare parameters
        self.declare_parameter("use_boost_acceleration", False)
        self.declare_parameter("use_obstacle_avoidance", False)
        self.declare_parameter("use_stats", False)
        self.declare_parameter("vehicle_id", os.environ.get("VEHICLE_ID", "default"))

        # get parameters
        self.use_sim_time = self.get_parameter("use_sim_time").get_parameter_value().bool_value
        self.USE_BUG_ACC = self.get_parameter("use_boost_acceleration").get_parameter_value().bool_value
        self.USE_OBSTACLE_AVOIDANCE = self.get_parameter("use_obstacle_avoidance").get_parameter_value().bool_value
        self.use_stats = self.get_parameter("use_stats").get_parameter_value().bool_value
        self._vehicle_id = self.get_parameter("vehicle_id").get_parameter_value().string_value
        if self._vehicle_id in ["default", "A0", ""]:
            domain_id = int(os.environ.get("ROS_DOMAIN_ID", "1"))
            self._vehicle_id = f"d{domain_id}"
        self.get_logger().info(f"VEHICLE ID INITIALIZED AS: {self._vehicle_id} (ROS_DOMAIN_ID={os.environ.get('ROS_DOMAIN_ID', '1')})")

        self._config_path = config_path
        self._ref_vel_config_path: Optional[str] = ref_vel_config_path
        self._cfg = self._load_config()
        self._odom: Optional[Odometry] = None
        self._enable_control = True
        self._initialize()
        self._setup_parameters_callback()
        self._setup_pub_sub()

        if self.use_sim_time:
            self.get_logger().warn("------------------------------------")
            self.get_logger().warn("use_sim_time is enabled!")
            self.get_logger().warn("------------------------------------")
        if self.USE_BUG_ACC:
            self.get_logger().warn("------------------------------------")
            self.get_logger().warn("USE_BUG_ACC is enabled!")
            self.get_logger().warn("------------------------------------")
        if self.USE_OBSTACLE_AVOIDANCE:
            self.get_logger().warn("------------------------------------")
            self.get_logger().warn("USE_OBSTACLE_AVOIDANCE is enabled!")
            self.get_logger().warn("------------------------------------")

    def _load_config(self) -> NamedTuple:

        # logging content
        with open(self._config_path, "r") as f:
            config_content = f.read()
            self.get_logger().info(
                "\n" +
                "----- config.yaml -----\n"+
                config_content + "\n" +
                "-----------------------")

        if self._ref_vel_config_path is not None:
            with open(self._ref_vel_config_path, "r") as f:
                ref_vel_config_content = f.read()
                self.get_logger().info(
                    "\n" +
                    "----- ref_vel.yaml -----\n"+
                    ref_vel_config_content + "\n" +
                    "-----------------------")

        with open(self._config_path, "r") as f:
            cfg: NamedTuple = convert_to_namedtuple(yaml.safe_load(f)) # type: ignore

        # Check if the files exist
        mandatory_files = [cfg.map.yaml_path, cfg.waypoints.csv_path] # type: ignore
        for file_path in mandatory_files:
            file_exists(self.in_pkg_share(file_path))
        return cfg

    def _create_reference_path_from_autoware_trajectory(self, trajectory: Trajectory) -> Optional[ReferencePath]:
        wp_x = [0] * len(trajectory.points)
        wp_y = [0] * len(trajectory.points)
        for i, p in enumerate(trajectory.points):
            wp_x[i] = p.pose.position.x
            wp_y[i] = p.pose.position.y

        cfg_ref_path = self._cfg.reference_path # type: ignore
        reference_path = ReferencePath(
            self._map,
            wp_x,
            wp_y,
            cfg_ref_path.resolution,
            cfg_ref_path.smoothing_distance,
            cfg_ref_path.max_width,
            cfg_ref_path.circular)

        mpc_config = self._mpc_cfg
        speed_profile_constraints = {
            "a_min": mpc_config.a_min, "a_max": mpc_config.a_max,
            "v_min": 0.0, "v_max": mpc_config.v_max, "ay_max": mpc_config.ay_max}

        if not reference_path.compute_speed_profile(speed_profile_constraints):
            return None

        return reference_path

    def _setup_parameters_callback(self) -> None:
        def declatre_parameters():
            cfg_mpc = self._cfg.mpc
            self.declare_parameter("v_max", cfg_mpc.v_max)
            self.declare_parameter("steering_tire_angle_gain_var", cfg_mpc.steering_tire_angle_gain_var)
            self.declare_parameter("Q0", cfg_mpc.Q[0])
            self.declare_parameter("Q1", cfg_mpc.Q[1])
            self.declare_parameter("Q2", cfg_mpc.Q[2])
            self.declare_parameter("R0", cfg_mpc.R[0])
            self.declare_parameter("R1", cfg_mpc.R[1])
            self.declare_parameter("QN0", cfg_mpc.QN[0])
            self.declare_parameter("QN1", cfg_mpc.QN[1])
            self.declare_parameter("QN2", cfg_mpc.QN[2])

            mpc_cfg = self._mpc_cfg
            self.declare_parameter("ay_max", mpc_cfg.ay_max)
            self.declare_parameter("accel_low_pass_gain", mpc_cfg.accel_low_pass_gain)
            self.declare_parameter("steer_low_pass_gain", mpc_cfg.steer_low_pass_gain)
            self.declare_parameter("wp_id_offset", mpc_cfg.wp_id_offset)

        def param_cb(parameters):
            cfg_mpc = self._cfg.mpc # type: ignore
            mpc_cfg = self._mpc_cfg

            def update_Q(index: int, value: float):
                cfg_mpc.Q[index] = value
                mpc_cfg.Q = sparse.diags(cfg_mpc.Q)
                self._mpc.update_Q(mpc_cfg.Q)
                self.get_logger().warn(f"Q[{index}] was updated to '{value}'")

            def update_R(index: int, value: float):
                cfg_mpc.R[index] = value
                mpc_cfg.R = sparse.diags(cfg_mpc.R)
                self._mpc.update_R(mpc_cfg.R)
                self.get_logger().warn(f"R[{index}] was updated to '{value}'")

            def update_QN(index: int, value: float):
                cfg_mpc.QN[index] = value
                mpc_cfg.QN = sparse.diags(cfg_mpc.QN)
                self._mpc.update_QN(mpc_cfg.QN)
                self.get_logger().warn(f"QN[{index}] was updated to '{value}'")

            for param in parameters:
                if param.name == "v_max" and param.type_ == Parameter.Type.DOUBLE:
                    mpc_cfg.v_max = param.value
                    self._mpc.update_v_max(kmh_to_m_per_sec(param.value))
                    v_ref: List[float] = [kmh_to_m_per_sec(param.value)] * len(self._reference_path.waypoints)
                    self._reference_path.set_v_ref(v_ref)

                    self.get_logger().warn(f"v_max was updated to '{param.value}' [km/h]")

                elif param.name == "steering_tire_angle_gain_var" and param.type_ == Parameter.Type.DOUBLE:
                    mpc_cfg.steering_tire_angle_gain_var = param.value
                    self.get_logger().warn(f"steering_tire_angle_gain_var was updated to '{param.value}'")

                elif param.name == "Q0" and param.type_ == Parameter.Type.DOUBLE:
                    update_Q(0, param.value)
                elif param.name == "Q1" and param.type_ == Parameter.Type.DOUBLE:
                    update_Q(1, param.value)
                elif param.name == "Q2" and param.type_ == Parameter.Type.DOUBLE:
                    update_Q(2, param.value)


                elif param.name == "R0" and param.type_ == Parameter.Type.DOUBLE:
                    update_R(0, param.value)
                elif param.name == "R1" and param.type_ == Parameter.Type.DOUBLE:
                    update_R(1, param.value)

                elif param.name == "QN0" and param.type_ == Parameter.Type.DOUBLE:
                    update_QN(0, param.value)
                elif param.name == "QN1" and param.type_ == Parameter.Type.DOUBLE:
                    update_QN(1, param.value)
                elif param.name == "QN2" and param.type_ == Parameter.Type.DOUBLE:
                    update_QN(2, param.value)

                elif param.name == "ay_max" and param.type_ == Parameter.Type.DOUBLE:
                    mpc_cfg.ay_max = param.value
                    self._mpc.update_ay_max(param.value)
                    self.get_logger().warn(f"ay_max was updated to '{param.value}'")

                elif param.name == "accel_low_pass_gain" and param.type_ == Parameter.Type.DOUBLE:
                    mpc_cfg.accel_low_pass_gain = param.value
                    self.get_logger().warn(f"accel_low_pass_gain was updated to '{param.value}'")

                elif param.name == "steer_low_pass_gain" and param.type_ == Parameter.Type.DOUBLE:
                    mpc_cfg.steer_low_pass_gain = param.value
                    self.get_logger().warn(f"steer_low_pass_gain was updated to '{param.value}'")

                elif param.name == "wp_id_offset" and param.type_ == Parameter.Type.INTEGER:
                    mpc_cfg.wp_id_offset = param.value
                    self._mpc.update_wp_id_offset(param.value)
                    self.get_logger().warn(f"wp_id_offset was updated to '{param.value}'")


            return SetParametersResult(successful=True)

        declatre_parameters()
        self.add_on_set_parameters_callback(param_cb)

    def _initialize(self) -> None:
        def create_map() -> Map:
            return Map(self.in_pkg_share(self._cfg.map.yaml_path)) # type: ignore

        def create_ref_path(map: Map) -> ReferencePath:
            cfg_ref_path = self._cfg.reference_path # type: ignore

            is_ref_path_given = cfg_ref_path.csv_path != "" # type: ignore
            if is_ref_path_given:
                print("Using given reference path")
                wp_x, wp_y, _, _ = load_ref_path(self.in_pkg_share(self._cfg.reference_path.csv_path)) # type: ignore
                return ReferencePath(
                    map,
                    wp_x,
                    wp_y,
                    cfg_ref_path.resolution,
                    cfg_ref_path.smoothing_distance,
                    cfg_ref_path.max_width,
                    cfg_ref_path.circular)

            else:
                print("Using waypoints to create reference path")
                wp_x, wp_y = load_waypoints(self.in_pkg_share(self._cfg.waypoints.csv_path)) # type: ignore

                return ReferencePath(
                    map,
                    wp_x,
                    wp_y,
                    cfg_ref_path.resolution,
                    cfg_ref_path.smoothing_distance,
                    cfg_ref_path.max_width,
                    cfg_ref_path.circular)


        def create_obstacles() -> List[Obstacle]:
            use_csv_obstacles = self._cfg.obstacles.csv_path != "" # type: ignore
            if use_csv_obstacles:
                obstacles_file_path = self.in_pkg_share(self._cfg.obstacles.csv_path) # type: ignore
                obs_x, obs_y = load_waypoints(obstacles_file_path)
                obstacles = []
                for cx, cy in zip(obs_x, obs_y):
                    obstacles.append(Obstacle(cx=cx, cy=cy, radius=self._cfg.obstacles.radius)) # type: ignore
                self._obstacle_manager = ObstacleManager(self._map, obstacles)
                return obstacles
            else:
                return []

        def create_car(ref_path: ReferencePath) -> BicycleModel:
            cfg_model = self._cfg.bicycle_model # type: ignore
            return BicycleModel(
                ref_path,
                cfg_model.length,
                cfg_model.width,
                1.0 / self._cfg.mpc.control_rate) # type: ignore

        def create_mpc(car: BicycleModel) -> Tuple[MPCConfig, MPC]:
            cfg_mpc = self._cfg.mpc # type: ignore

            mpc_cfg = MPCConfig(
                cfg_mpc.N,
                sparse.diags(cfg_mpc.Q),
                sparse.diags(cfg_mpc.R),
                sparse.diags(cfg_mpc.QN),
                kmh_to_m_per_sec(self.BUG_VEL if self.USE_BUG_ACC else cfg_mpc.v_max),
                cfg_mpc.a_min,
                cfg_mpc.a_max,
                cfg_mpc.ay_max,
                np.deg2rad(cfg_mpc.delta_max_deg),
                cfg_mpc.steer_rate_max,
                cfg_mpc.control_rate,
                cfg_mpc.steering_tire_angle_gain_var,
                cfg_mpc.accel_low_pass_gain,
                cfg_mpc.steer_low_pass_gain,
                cfg_mpc.wp_id_offset,
                cfg_mpc.use_max_kappa_pred)

            state_constraints = {
                "xmin": np.array([-np.inf, -np.inf, -np.inf]),
                "xmax": np.array([np.inf, np.inf, np.inf])}
            input_constraints = {
                "umin": np.array([0.0, -np.tan(mpc_cfg.delta_max) / car.length]),
                "umax": np.array([mpc_cfg.v_max, np.tan(mpc_cfg.delta_max) / car.length])}

            # mpcからのsteer指令出力は、gainを掛けて出力され、その状態で車体のsteer rate limit が適用されるため、
            # mpcの制御計算におけるsteer_rate_maxは、実際のsteer_rate_maxをgainで除した値で設定する
            scaled_steer_rate_max = mpc_cfg.steer_rate_max / mpc_cfg.steering_tire_angle_gain_var

            mpc = MPC(
                car,
                mpc_cfg.N,
                mpc_cfg.Q,
                mpc_cfg.R,
                mpc_cfg.QN,
                state_constraints,
                input_constraints,
                mpc_cfg.ay_max,
                scaled_steer_rate_max,
                mpc_cfg.wp_id_offset,
                self.USE_OBSTACLE_AVOIDANCE,
                self._cfg.reference_path.use_path_constraints_topic,
                mpc_cfg.use_max_kappa_pred)

            return mpc_cfg, mpc

        def compute_speed_profile(car: BicycleModel, mpc_config: MPCConfig) -> None:
            speed_profile_constraints = {
                "a_min": mpc_config.a_min, "a_max": mpc_config.a_max,
                "v_min": 0.0, "v_max": mpc_config.v_max, "ay_max": mpc_config.ay_max}
            car.reference_path.compute_speed_profile(speed_profile_constraints)

        def create_ref_vel_configulator() -> Optional[ReferenceVelocityConfigulator]:
            if self._ref_vel_config_path is None:
                return None
            return ReferenceVelocityConfigulator(self, self._config_path, self._ref_vel_config_path)

        def create_pp_ref_vel_configulator() -> Optional[ReferenceVelocityConfigulator]:
            pp = getattr(self._cfg, "pure_pursuit", None)
            pp_ref_vel_path = getattr(pp, "ref_vel_path", None) if pp else None
            if pp_ref_vel_path is not None:
                full_path = self.in_pkg_share(pp_ref_vel_path) if not os.path.isabs(pp_ref_vel_path) else pp_ref_vel_path
                if os.path.exists(full_path):
                    self.get_logger().info(f"Loaded Pure Pursuit specific ref_vel: {full_path}")
                    return ReferenceVelocityConfigulator(self, self._config_path, full_path, param_prefix="ref_vel_pp")
            return self._ref_vel_configulator

        self._map = create_map()
        self._reference_path = create_ref_path(self._map)
        self._car = create_car(self._reference_path)
        self._mpc_cfg, self._mpc = create_mpc(self._car)
        compute_speed_profile(self._car, self._mpc_cfg)

        self._ref_vel_configulator: Optional[ReferenceVelocityConfigulator] = create_ref_vel_configulator()
        self._ref_vel_configulator_pp: Optional[ReferenceVelocityConfigulator] = create_pp_ref_vel_configulator()

        self._trajectory: Optional[Trajectory] = None
        self._path_constraints = None

        # Obstacles
        if self.USE_OBSTACLE_AVOIDANCE:
            self._static_obstacles: List[Obstacle] = create_obstacles()
            self._dynamic_obstacles: List[Obstacle] = []
            self._obstacles_updated = bool(self._static_obstacles)
            v2x_cfg = self._cfg.v2x_obstacle_avoidance  # type: ignore
            self._v2x_tracker = V2XVehicleTracker(
                v_max_safety=float(v2x_cfg.v_max_safety),
                position_jump_threshold=float(v2x_cfg.position_jump_threshold),
                warn_callback=self.get_logger().warn,
            )
            self._v2x_vehicle_radius = float(v2x_cfg.vehicle_radius)
            mpc_N = int(self._cfg.mpc.N)  # type: ignore
            t_horizon = mpc_N / float(self._cfg.mpc.control_rate)  # type: ignore
            self._v2x_t_samples = [
                k * t_horizon / max(mpc_N - 1, 1) for k in range(mpc_N)
            ]
            # コリドー外の V2X 障害物で MPC のコリドー狭窄/反転が起きないよう、
            # ref-path 近傍のみに絞り込む。閾値 = max_width/2 + vehicle_radius + 余白。
            ref_max_width = float(self._cfg.reference_path.max_width)  # type: ignore
            self._v2x_corridor_threshold_sq = (
                ref_max_width / 2.0 + self._v2x_vehicle_radius + 0.5
            ) ** 2
            wps = self._reference_path.waypoints
            self._waypoint_xy = np.asarray(
                [(wp.x, wp.y) for wp in wps], dtype=np.float64)

        # Laps
        self._current_laps = 1
        self._last_lap_time = 0.0
        self._lap_times = [None] * (self.MAX_LAPS + 1) # +1 means include lap 0

        # condition
        self._last_condition = None
        self._last_colliding_time = None

        # --- Stuck detection ---
        self._stopped_since = None  # time when velocity first dropped near zero
        self._start_time = None
        self._last_recovery_exit_time = None

        # stats
        self._stats = ExecutionStats(self.get_logger(), window_size=50, record_count_threshold=1000)

        # --- State machine ---------------------------------------------------
        self._target_lateral_offset = 0.0
        self._current_lateral_offset = 0.0
        self._state_manager = StateManager(self)
        self._lidar_processor = LidarProcessor(self)

        # V2X tracker for state context — always initialise so the state
        # machine can detect forward vehicles regardless of obstacle-avoidance
        # mode.  When USE_OBSTACLE_AVOIDANCE is True the tracker is already
        # created above (line ~459); only create it here if it was skipped.
        if not hasattr(self, '_v2x_tracker'):
            v2x_cfg = self._cfg.v2x_obstacle_avoidance  # type: ignore
            self._v2x_tracker = V2XVehicleTracker(
                v_max_safety=float(v2x_cfg.v_max_safety),
                position_jump_threshold=float(v2x_cfg.position_jump_threshold),
                warn_callback=self.get_logger().warn,
            )

        # Precompute waypoint array for path-deviation calculation — always
        # needed by the state machine even when obstacle avoidance is active.
        wps = self._reference_path.waypoints
        self._waypoint_xy = np.asarray(
            [(wp.x, wp.y) for wp in wps], dtype=np.float64)

        self.get_logger().info("[StateManager] Initialised — starting in 'follow_path'")

        # save config
        if self._cfg.common.save_config:
            self._save_config()

    def _save_config(self) -> None:
        now = datetime.now().strftime("%Y%m%d_%H%M%S")
        dst_dir = self.PKG_PATH + f"log/{now}"
        os.makedirs(dst_dir, exist_ok=True)
        shutil.copy(self._config_path, os.path.join(dst_dir, "config.yaml"))

    def _setup_pub_sub(self) -> None:
        # Publishers
        if self.USE_BUG_ACC:
          self._command_pub = self.create_publisher(
            AckermannControlBoostCommand, "/boost_commander/command", 1)
          self._command_raw_pub = self.create_publisher(
            AckermannControlBoostCommand, "/boost_commander/command_raw", 1)
        else:
          self._command_pub = self.create_publisher(
            AckermannControlCommand, "/control/command/control_cmd", 1)
          self._command_raw_pub = self.create_publisher(
            AckermannControlCommand, "/control/command/control_cmd_raw", 1)
          print("use normal ackermann control command")

        # Gear command publisher (if supported in environment)
        if HAS_GEAR_MSG:
            self._gear_cmd_pub = self.create_publisher(
                GearCommand, "/control/command/gear_cmd", 1)
        else:
            self._gear_cmd_pub = None

        # NOTE:評価環境での可視化のためにダミーのトピック名を使用
        self._mpc_pred_pub = self.create_publisher(
            MarkerArray, "/mpc/prediction", 1)
        self._mpc_pred_pub_dummy = self.create_publisher(
            MarkerArray, "/planning/scenario_planning/lane_driving/motion_planning/obstacle_stop_planner/virtual_wall", 1)

        latching_qos = QoSProfile(depth=1, durability=QoSDurabilityPolicy.TRANSIENT_LOCAL)
        # NOTE:評価環境での可視化のためにダミーのトピック名を使用
        self._ref_path_pub = self.create_publisher(
            MarkerArray, "/mpc/ref_path", latching_qos)
        self._ref_path_pub_dummy = self.create_publisher(
            MarkerArray, "/planning/scenario_planning/lane_driving/behavior_planning/behavior_path_planner/debug/bound", latching_qos)

        # Subscribers
        self._odom_sub = self.create_subscription(
            Odometry, "/localization/kinematic_state", self._odom_callback, 1)
        self._control_mode_request_sub = self.create_subscription(
            Bool, "control/control_mode_request_topic", self._control_mode_request_callback, 1)
        # simple_trajectory_generator publishes with BEST_EFFORT/KEEP_LAST(1) — match it
        # so the subscription is QoS-compatible (rclpy default is RELIABLE).
        trajectory_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self._trajectory_sub = self.create_subscription(
            Trajectory, "planning/scenario_planning/trajectory", self._trajectory_callback, trajectory_qos)
        self._stop_request_sub = self.create_subscription(
            Empty, "/control/mpc/stop_request", self._stop_request_callback, 1)

        if self.use_sim_time:
            self._awsim_status_sub = self.create_subscription(
                Float32MultiArray, "/awsim/status", self._awsim_status_callback, 1)
            self._condition_sub = self.create_subscription(
                Int32, "/aichallenge/pitstop/condition", self._condition_callback, 1)

        if self.USE_OBSTACLE_AVOIDANCE:
            if self._cfg.reference_path.use_path_constraints_topic: # type: ignore
                self._path_constraints_sub = self.create_subscription(
                    PathConstraints, "/path_constraints_provider/path_constraints", self._path_constraints_callback, 1)

            if self._cfg.reference_path.use_border_cells_topic: # type: ignore
                self._border_cells_sub = self.create_subscription(
                    BorderCells, "/path_constraints_provider/border_cells", self._border_cells_callback, 1)

        # V2X subscriber — always subscribe for state-machine context,
        # even when obstacle avoidance is disabled.
        self._v2x_sub = self.create_subscription(
            V2XVehiclePositionArray,
            "/v2x/vehicle_positions",
            self._v2x_callback,
            1)

    def _create_ackerman_control_command(self, stamp, u, acc, bug_acc_enabled):
        v_cmd = u[0]
        steer_cmd = u[1]

        ackerman_cmd = array_to_ackermann_control_command(stamp.to_msg(), [v_cmd, steer_cmd], acc)

        if not self.USE_BUG_ACC:
            return ackerman_cmd

        ackerman_boost_cmd = AckermannControlBoostCommand()
        ackerman_boost_cmd.command = ackerman_cmd
        ackerman_boost_cmd.boost_mode = bug_acc_enabled
        return ackerman_boost_cmd

    def _publish_control_command(self, stamp, u, acc, bug_acc_enabled):
        cmd = self._create_ackerman_control_command(stamp, u, acc, bug_acc_enabled)

        # compensate steering angle for the real vehicle (support both message formats)
        if isinstance(cmd, AckermannControlCommand):
            cmd.lateral.steering_tire_angle *= self._mpc_cfg.steering_tire_angle_gain_var
        elif hasattr(cmd, "command") and hasattr(cmd.command, "lateral"):
            cmd.command.lateral.steering_tire_angle *= self._mpc_cfg.steering_tire_angle_gain_var

        # publish raw control command
        if hasattr(self, "_command_raw_pub") and self._command_raw_pub is not None:
            self._command_raw_pub.publish(cmd)

        self._command_pub.publish(cmd)

    def _publish_gear_command(self, stamp, gear_val: int) -> None:
        if not HAS_GEAR_MSG or self._gear_cmd_pub is None:
            return
        gear_msg = GearCommand()
        gear_msg.stamp = stamp
        gear_msg.command = gear_val
        self._gear_cmd_pub.publish(gear_msg)


    def _odom_callback(self, msg: Odometry) -> None:
        self._odom = msg

    def _control_mode_request_callback(self, msg):
        if msg.data and not self._enable_control:
            self.get_logger().info("Control mode request received")
            self._enable_control = True
            self._start_time = self.get_clock().now().nanoseconds / 1e9

    def _path_constraints_callback(self, msg: PathConstraints):
        self._reference_path.set_path_constraints(
            msg.upper_bounds, msg.lower_bounds, msg.rows, msg.cols)

    def _v2x_callback(self, msg: V2XVehiclePositionArray) -> None:
        self._v2x_tracker.update(msg)
        active_ids = self._v2x_tracker.active_vehicle_ids()
        self.get_logger().info(f"V2X active ids: {active_ids}, ego id: {self._vehicle_id}", throttle_duration_sec=2.0)

        if self.USE_OBSTACLE_AVOIDANCE:
            predictions = {}
            for vid in active_ids:
                if vid == self._vehicle_id:
                    continue  # Exclude self vehicle
                predictions[vid] = self._v2x_tracker.predict_positions(vid, self._v2x_t_samples)
            self._dynamic_obstacles = predictions_to_obstacles(
                predictions, self._v2x_vehicle_radius)
            self._obstacles_updated = True

    def _filter_obstacles_to_corridor(self, obstacles: List[Obstacle]) -> List[Obstacle]:
        if not obstacles or self._waypoint_xy.size == 0:
            return obstacles
        thr_sq = self._v2x_corridor_threshold_sq
        wps = self._waypoint_xy
        kept: List[Obstacle] = []
        for ob in obstacles:
            dxy = wps - np.array([ob.cx, ob.cy], dtype=np.float64)
            if np.min(np.einsum('ij,ij->i', dxy, dxy)) <= thr_sq:
                kept.append(ob)
        return kept

    def _border_cells_callback(self, msg: BorderCells):
        self._reference_path.set_border_cells(
            msg.dynamic_upper_bounds, msg.dynamic_lower_bounds, msg.rows, msg.cols)

    def _trajectory_callback(self, msg):
        self._trajectory = msg

    def _awsim_status_callback(self, msg):
        laps = int(msg.data[1])
        lap_time = msg.data[2]
        # section = int(msg.data[3])

        if self._current_laps is None:
            self._current_laps = 1 if laps == 0 else laps

        if laps > self._current_laps:
            self.get_logger().info(f'\033[32mLap {self._current_laps} completed! Lap time: {self._last_lap_time} s\033[0m')
            self._lap_times[self._current_laps] = self._last_lap_time
            self._current_laps = laps

        self._last_lap_time = lap_time

    def _condition_callback(self, msg: Int32):
        if self._last_condition is None:
            self._last_condition = msg.data

        diff_condition = msg.data - self._last_condition
        if diff_condition > 30.0:
            self._last_colliding_time = self.get_clock().now()
            self.get_logger().warning(f"Collision detected!")
        self._last_condition = msg.data

    def _stop_request_callback(self, msg: Empty) -> None:
        if self._enable_control:
            self.get_logger().warn(f"Stop request received {self._enable_control}")
            self._enable_control = False

    def _wait_until_clock_received(self) -> None:
        if self.use_sim_time:
            self.get_logger().info(f"wait until clock received...")
            rate = self.create_rate(10)
            rate.sleep()
            self.get_logger().info(f">> OK!")

    def _wait_until_message_received(self, message_getter, message_name: str, timeout: float, rate_hz: int = 30) -> None:

        t_start = self.get_clock().now()
        rate = self.create_rate(rate_hz)

        self.get_logger().info(f"wait until {message_name} received...")

        while message_getter() is None:
            now = self.get_clock().now()
            if (now - t_start).nanoseconds > timeout * 1e9:
                self.get_logger().info(f"now: {now}, t_start: {t_start}")
                raise TimeoutError(f"Timeout while waiting for {message_name} message")
            rate.sleep()

        self.get_logger().info(f">> OK!")

    def _wait_until_odom_received(self, timeout: float = 30.) -> None:
        self._wait_until_message_received(lambda: self._odom, 'odometry', timeout)

    def _wait_until_trajectory_received(self, timeout: float = 30.) -> None:
        if self._cfg.reference_path.update_by_topic:
            self._wait_until_message_received(lambda: self._trajectory, 'trajectory', timeout)

    def _wait_until_path_constraints_received(self, timeout: float = 30.) -> None:
        if self.USE_OBSTACLE_AVOIDANCE and self._cfg.reference_path.use_path_constraints_topic: # type: ignore
            self._wait_until_message_received(lambda: self._reference_path.path_constraints, 'path constraints', timeout)

    def _publish_mpc_pred_marker(self, x_pred, y_pred):
        pred_marker_array = MarkerArray()
        m_base = Marker()
        m_base.header.frame_id = "map"
        m_base.ns = "mpc_pred"
        m_base.type = Marker.SPHERE
        m_base.action = Marker.ADD
        m_base.pose.position.z = 0.0
        m_base.scale = Vector3(x=0.5, y=0.5, z=0.5)
        m_base.color = self._pred_marker_color
        for i in range(len(x_pred)):
            m = copy.deepcopy(m_base)
            m.id = i
            m.pose.position.x = x_pred[i]
            m.pose.position.y = y_pred[i]
            pred_marker_array.markers.append(m) # type: ignore
        self._mpc_pred_pub.publish(pred_marker_array)
        self._mpc_pred_pub_dummy.publish(pred_marker_array)

    def _publish_ref_path_marker(self, ref_path: ReferencePath):
        WP_SPHERE_ENABLED = False

        ref_path_marker_array = MarkerArray()

        m_base = Marker()
        m_base.header.frame_id = "map"
        m_base.ns = "ref_path"
        m_base.type = Marker.LINE_STRIP
        m_base.action = Marker.ADD
        m_base.pose.position.z = 0.0
        m_base.scale.x = 0.2
        m_base.color = ColorRGBA(r=0.0, g=0.0, b=1.0, a=0.7)

        for i in range(len(ref_path.waypoints) - 1):
            m = copy.deepcopy(m_base)
            m.id = i
            start = Point()
            start.x = ref_path.waypoints[i].x
            start.y = ref_path.waypoints[i].y
            end = Point()
            end.x = ref_path.waypoints[i + 1].x
            end.y = ref_path.waypoints[i + 1].y
            m.points.append(start) # type: ignore
            m.points.append(end) # type: ignore
            ref_path_marker_array.markers.append(m) # type: ignore

        if WP_SPHERE_ENABLED:
            spheres = Marker()
            spheres.header.frame_id = "map"
            spheres.ns = "ref_path_point"
            spheres.type = Marker.SPHERE_LIST
            spheres.action = Marker.ADD
            radius = 0.2
            spheres.scale = Vector3(x=radius, y=radius, z=radius)
            spheres.color = ColorRGBA(r=1.0, g=1.0, b=0.0, a=0.7)
            for i in range(len(ref_path.waypoints) - 1):
                p = Point()
                p.x = ref_path.waypoints[i].x
                p.y = ref_path.waypoints[i].y
                p.z = 0.
                spheres.points.append(p) #type: ignore
            ref_path_marker_array.markers.append(spheres) # type: ignore

        self._ref_path_pub.publish(ref_path_marker_array)
        self._ref_path_pub_dummy.publish(ref_path_marker_array)

    # ------------------------------------------------------------------
    # State-machine helpers
    # ------------------------------------------------------------------

    def _compute_pure_pursuit_control(self, pose, v_current: float) -> Tuple[float, float]:
        """Compute (target_speed_mps, steer_cmd) mirroring simple_pure_pursuit.cpp algorithm with safety guard."""
        default_speed = kmh_to_m_per_sec(35.0)
        if pose is None or self._waypoint_xy is None or len(self._waypoint_xy) == 0:
            return default_speed, 0.0

        try:
            pp = getattr(self._cfg, "pure_pursuit", None)
            wheel_base = float(getattr(pp, "wheel_base", 1.087)) if pp else 1.087
            lookahead_gain = float(getattr(pp, "lookahead_gain", 0.25)) if pp else 0.25
            lookahead_min = float(getattr(pp, "lookahead_min_distance", 2.0)) if pp else 2.0
            speed_scale = float(getattr(pp, "speed_scale_factor", 1.0)) if pp else 1.0
            steer_gain = float(getattr(pp, "steering_tire_angle_gain", 1.0)) if pp else 1.0
            use_ext_v = bool(getattr(pp, "use_external_target_vel", False)) if pp else False
            ext_v = float(getattr(pp, "external_target_vel", 0.0)) if pp else 0.0

            car_xy = np.array([pose.x, pose.y], dtype=np.float64)
            diffs = self._waypoint_xy - car_xy
            dists_sq = np.einsum("ij,ij->i", diffs, diffs)
            closest_idx = int(np.argmin(dists_sq))
            closest_wp = self._reference_path.waypoints[closest_idx]

            # Sync wp_id for velocity configulator compatibility
            if hasattr(self._mpc, "model") and hasattr(self._mpc.model, "wp_id"):
                self._mpc.model.wp_id = closest_idx

            if use_ext_v:
                base_v_mps = ext_v
            elif self._ref_vel_configulator_pp is not None:
                curr_v_mps = kmh_to_m_per_sec(float(self._ref_vel_configulator_pp.get_ref_vel(closest_idx)))
                n_w = len(self._reference_path.waypoints)
                ahead_v_mps = min(
                    kmh_to_m_per_sec(float(self._ref_vel_configulator_pp.get_ref_vel((closest_idx + k) % n_w)))
                    for k in range(0, 7, 2)
                )
                base_v_mps = min(curr_v_mps, ahead_v_mps)
            elif closest_wp.v_ref is not None:
                base_v_mps = float(closest_wp.v_ref)
            else:
                base_v_mps = default_speed
            target_longitudinal_vel = base_v_mps * speed_scale

            # Recovery Launch: limit speed to 14 km/h and expand lookahead to 3.5m for 2.0s after exiting recovery to smoothly clear corner apex
            now_sec = self.get_clock().now().nanoseconds / 1e9
            if self._last_recovery_exit_time is not None and (now_sec - self._last_recovery_exit_time) < 2.0:
                target_longitudinal_vel = min(target_longitudinal_vel, kmh_to_m_per_sec(14.0))
                lookahead_min = max(lookahead_min, 3.5)

            # FollowState: dynamically limit speed to maintain 5.5m safe distance behind leader
            if self._state_manager.current_state.name == "follow":
                current_state = self._state_manager.current_state
                if isinstance(current_state, FollowState):
                    ctx_for_follow = self._build_state_context(0.02, False)
                    follow_v_max = current_state.get_adjusted_v_max_kmh(ctx_for_follow)
                    target_longitudinal_vel = min(target_longitudinal_vel, kmh_to_m_per_sec(follow_v_max))

            # Push-to-Pass / Overtake Speed:
            if self._state_manager.current_state.name == "overtake":
                overtake_params = self._state_manager.current_state.get_params()
                full_overtake_v = kmh_to_m_per_sec(float(overtake_params.v_max))
                # Safety guard while transitioning into open lane (only for high-speed leader)
                ctx_ot = self._build_state_context(0.02, False)
                fwd_d = ctx_ot.forward_vehicle_distance
                fwd_spd = ctx_ot.forward_vehicle_speed
                if fwd_d is not None and fwd_d < 4.0 and abs(self._current_lateral_offset) < 0.8 and (fwd_spd is not None and fwd_spd >= 6.0):
                    safe_approach_v = fwd_spd + kmh_to_m_per_sec(4.0)  # smooth approach speed
                    target_longitudinal_vel = min(full_overtake_v, safe_approach_v)
                else:
                    target_longitudinal_vel = full_overtake_v

            lookahead_distance = lookahead_gain * target_longitudinal_vel + lookahead_min
            rear_x = pose.x - (wheel_base / 2.0) * np.cos(pose.theta)
            rear_y = pose.y - (wheel_base / 2.0) * np.sin(pose.theta)

            n_wps = len(self._reference_path.waypoints)
            target_idx = closest_idx
            for i in range(n_wps):
                idx = (closest_idx + i) % n_wps
                wp = self._reference_path.waypoints[idx]
                if np.hypot(wp.x - rear_x, wp.y - rear_y) >= lookahead_distance:
                    target_idx = idx
                    break

            lookahead_wp = self._reference_path.waypoints[target_idx]

            # Dynamic Wall Boundary Guard:
            # Guarantee target point is strictly inside track borders by at least MIN_WALL_MARGIN (0.90m)
            MIN_WALL_MARGIN = 0.90  # [m] (Car half-width 0.58m + 0.32m physical buffer)
            left_wall_d = float(lookahead_wp.ub_sm) if lookahead_wp.ub_sm is not None else (float(lookahead_wp.ub) if lookahead_wp.ub is not None else 3.0)
            right_wall_d = float(abs(lookahead_wp.lb_sm)) if lookahead_wp.lb_sm is not None else (float(abs(lookahead_wp.lb)) if lookahead_wp.lb is not None else 3.0)

            max_safe_left = max(0.0, left_wall_d - MIN_WALL_MARGIN)
            max_safe_right = max(0.0, right_wall_d - MIN_WALL_MARGIN)

            # Clamp offset strictly so target never violates left/right wall limit
            safe_offset = float(np.clip(self._current_lateral_offset, -max_safe_right, max_safe_left))

            # Apply lateral offset to lookahead waypoint to track shifted lane smoothly
            wp_psi = float(lookahead_wp.psi)
            target_x = lookahead_wp.x - safe_offset * np.sin(wp_psi)
            target_y = lookahead_wp.y + safe_offset * np.cos(wp_psi)

            alpha = np.arctan2(target_y - rear_y, target_x - rear_x) - pose.theta
            alpha = (alpha + np.pi) % (2 * np.pi) - np.pi

            steering_tire_angle = steer_gain * np.arctan2(
                2.0 * wheel_base * np.sin(alpha), lookahead_distance
            )
            steer_cmd = float(np.clip(steering_tire_angle, -0.55, 0.55))

            return target_longitudinal_vel, steer_cmd
        except Exception as e:
            self.get_logger().error(f"Error in pure pursuit calculation (fallback to default speed): {e}")
            return default_speed, 0.0

    def _compute_path_deviation(self) -> float:
        """Approximate lateral deviation from the reference path [m]."""
        car_xy = np.array(
            [self._car.temporal_state.x, self._car.temporal_state.y],
            dtype=np.float64,
        )
        diffs = self._waypoint_xy - car_xy
        dists_sq = np.einsum("ij,ij->i", diffs, diffs)
        return float(np.sqrt(np.min(dists_sq)))

    def _detect_forward_vehicle(self) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """Return (distance, speed, heading_rad) of the nearest V2X vehicle directly in front on the track corridor."""
        MAX_DIST = 22.0                    # 22m max forward detection distance along track
        MAX_LATERAL_DIFF = 4.5             # Lateral tolerance [m] covering full track width

        pose = odom_to_pose_2d(self._odom)  # type: ignore
        ego_linear_v = self._odom.twist.twist.linear.x if self._odom is not None else 10.0  # type: ignore
        best_dist: Optional[float] = None
        best_speed: Optional[float] = None
        best_heading: Optional[float] = None
        best_y_rel: Optional[float] = None
        best_x_rel: Optional[float] = None
        best_pred_y_rel: Optional[float] = None
        best_lead_pos: Optional[Tuple[float, float]] = None

        cos_t = np.cos(pose.theta)
        sin_t = np.sin(pose.theta)

        n_wps = len(self._reference_path.waypoints) if self._reference_path is not None else 0
        if n_wps == 0 or len(self._waypoint_xy) == 0:
            return None, None, None, None, None, None, None, None

        # Ego's closest waypoint on raceline
        ego_xy = np.array([pose.x, pose.y], dtype=np.float64)
        ego_diffs = self._waypoint_xy - ego_xy
        ego_closest_idx = int(np.argmin(np.einsum("ij,ij->i", ego_diffs, ego_diffs)))

        best_track_s: Optional[float] = None

        for vid in self._v2x_tracker.active_vehicle_ids():
            if vid == self._vehicle_id:
                continue  # Exclude self vehicle

            buf = self._v2x_tracker._samples.get(vid)
            if not buf:
                continue
            _, vx_pos, vy_pos = buf[-1]

            # Find target vehicle waypoint index on raceline
            lead_xy = np.array([vx_pos, vy_pos], dtype=np.float64)
            lead_diffs = self._waypoint_xy - lead_xy
            lead_closest_idx = int(np.argmin(np.einsum("ij,ij->i", lead_diffs, lead_diffs)))

            # Track distance along raceline (waypoints are ~0.8m apart)
            wp_diff = (lead_closest_idx - ego_closest_idx) % n_wps
            if wp_diff > n_wps / 2:
                wp_diff -= n_wps  # negative means behind ego

            # Forward on track: wp_diff in [0, 30] (approx 0 to 24 meters ahead along track)
            is_forward_on_track = (wp_diff >= 0 and wp_diff <= 30)

            dx = vx_pos - pose.x
            dy = vy_pos - pose.y
            dist = float(np.hypot(dx, dy))

            # Transform to ego-vehicle local coordinates
            x_rel = cos_t * dx + sin_t * dy
            y_rel = -sin_t * dx + cos_t * dy

            # Check if vehicle is ahead (either by track index or by ego body frame)
            if not is_forward_on_track and x_rel <= 0.0:
                continue

            if dist > MAX_DIST:
                continue

            # Ensure vehicle is laterally on/near track corridor (Frenet frame)
            lead_wp = self._reference_path.waypoints[lead_closest_idx]
            lead_dx = vx_pos - lead_wp.x
            lead_dy = vy_pos - lead_wp.y
            lead_psi = float(lead_wp.psi)
            lead_ey = float(-lead_dx * np.sin(lead_psi) + lead_dy * np.cos(lead_psi))
            if abs(lead_ey) > MAX_LATERAL_DIFF:
                continue

            if best_dist is None or dist < best_dist:
                best_dist = dist
                best_x_rel = float(max(0.1, x_rel)) if is_forward_on_track else float(x_rel)
                best_track_s = float(wp_diff * 0.80)
                best_y_rel = float(y_rel)
                best_lead_pos = (float(vx_pos), float(vy_pos))
                vx_vel, vy_vel = self._v2x_tracker.velocity(vid)
                best_speed = float(np.hypot(vx_vel, vy_vel))

                lead_v = best_speed if best_speed > 0.5 else 6.94
                ego_v = max(ego_linear_v, 10.0)
                delta_v = max(ego_v - lead_v, 1.5)
                t_pass = np.clip(dist / delta_v, 0.2, 3.0)

                pred_lx = vx_pos + vx_vel * t_pass
                pred_ly = vy_pos + vy_vel * t_pass
                best_pred_y_rel = float(-sin_t * (pred_lx - pose.x) + cos_t * (pred_ly - pose.y))

                if best_speed > 0.3:
                    best_heading = float(np.arctan2(vy_vel, vx_vel))
                elif len(buf) >= 2:
                    dx_v = buf[-1][1] - buf[0][1]
                    dy_v = buf[-1][2] - buf[0][2]
                    if np.hypot(dx_v, dy_v) > 0.05:
                        best_heading = float(np.arctan2(dy_v, dx_v))

        return best_dist, best_speed, best_heading, best_y_rel, best_x_rel, best_pred_y_rel, best_lead_pos, best_track_s

    def _build_state_context(self, dt: float, is_colliding: bool) -> StateContext:
        """Assemble a StateContext snapshot for the current tick."""
        now_sec = self.get_clock().now().nanoseconds / 1e9
        pose = odom_to_pose_2d(self._odom)  # type: ignore
        v = self._odom.twist.twist.linear.x  # type: ignore

        time_since_collision: Optional[float] = None
        if self._last_colliding_time is not None:
            time_since_collision = (
                self.get_clock().now() - self._last_colliding_time
            ).nanoseconds / 1e9

        # --- Stuck detection: track how long velocity has been near zero ---
        STOPPED_THRESHOLD = 0.3  # [m/s]
        # Do not count stuck time before control is enabled or during startup (10.0s)
        if not self._enable_control or self._start_time is None or (now_sec - self._start_time) < 10.0:
            self._stopped_since = None
            time_stopped = 0.0
        elif abs(v) < STOPPED_THRESHOLD:
            if self._stopped_since is None:
                self._stopped_since = now_sec
            time_stopped = now_sec - self._stopped_since
        else:
            self._stopped_since = None
            time_stopped = 0.0

        fwd_dist, fwd_speed, fwd_heading, fwd_y_rel, fwd_x_rel, fwd_pred_y_rel, fwd_pos, fwd_track_s = self._detect_forward_vehicle()
        lidar_clearance = fwd_dist
        range_clearance = fwd_dist

        if self._start_time is None:
            self._start_time = now_sec

        # Cooldown check: 3.0s after startup or 3.5s after exiting RecoveryState
        is_cooldown = False
        if (now_sec - self._start_time) < 3.0:
            is_cooldown = True
        if self._last_recovery_exit_time is not None:
            if (now_sec - self._last_recovery_exit_time) < 3.5:
                is_cooldown = True

        # Closest waypoint orientation & signed lateral distance
        car_xy = np.array([pose.x, pose.y], dtype=np.float64)
        diffs = self._waypoint_xy - car_xy
        dists_sq = np.einsum("ij,ij->i", diffs, diffs)
        closest_idx = int(np.argmin(dists_sq))
        closest_wp = self._reference_path.waypoints[closest_idx]

        path_psi = float(closest_wp.psi)
        path_kappa = float(closest_wp.kappa) if hasattr(closest_wp, "kappa") and closest_wp.kappa is not None else 0.0
        n_wps = len(self._reference_path.waypoints)
        future_kappas = [
            abs(float(self._reference_path.waypoints[(closest_idx + k) % n_wps].kappa))
            for k in range(25)
            if hasattr(self._reference_path.waypoints[(closest_idx + k) % n_wps], "kappa")
        ]
        future_max_kappa = max(future_kappas) if future_kappas else abs(path_kappa)

        # Check if approaching straight zone (ahead 8-25 waypoints is straight)
        upcoming_kappas = [
            abs(float(self._reference_path.waypoints[(closest_idx + k) % n_wps].kappa))
            for k in range(8, 25)
            if hasattr(self._reference_path.waypoints[(closest_idx + k) % n_wps], "kappa")
        ]
        is_approaching_straight = (max(upcoming_kappas) < 0.04) if upcoming_kappas else False

        dx = pose.x - closest_wp.x
        dy = pose.y - closest_wp.y
        path_e_y = float(-dx * np.sin(path_psi) + dy * np.cos(path_psi))

        # True clearance from reference path to left/right track boundaries (from Occupancy Grid bounds)
        if closest_wp.ub_sm is not None:
            path_left_wall = float(closest_wp.ub_sm)
        elif closest_wp.ub is not None:
            path_left_wall = float(closest_wp.ub)
        else:
            path_left_wall = float(self._cfg.reference_path.max_width) / 2.0

        if closest_wp.lb_sm is not None:
            path_right_wall = float(abs(closest_wp.lb_sm))
        elif closest_wp.lb is not None:
            path_right_wall = float(abs(closest_wp.lb))
        else:
            path_right_wall = float(self._cfg.reference_path.max_width) / 2.0

        # Future minimum corridor bounds over next ~20m horizon (lookahead for overtake)
        future_min_path_left_wall = path_left_wall
        future_min_path_right_wall = path_right_wall
        if self._reference_path is not None and len(self._reference_path.waypoints) > 0:
            n_wps = len(self._reference_path.waypoints)
            left_bounds = []
            right_bounds = []
            for i in range(25):
                idx = (closest_idx + i) % n_wps
                wp = self._reference_path.waypoints[idx]
                lw = float(wp.ub_sm) if wp.ub_sm is not None else (float(wp.ub) if wp.ub is not None else 3.0)
                rw = float(abs(wp.lb_sm)) if wp.lb_sm is not None else (float(abs(wp.lb)) if wp.lb is not None else 3.0)
                left_bounds.append(lw)
                right_bounds.append(rw)
            future_min_path_left_wall = float(min(left_bounds))
            future_min_path_right_wall = float(min(right_bounds))

        # Calculate available overtake width using REAL track bounds at the leader waypoint
        if fwd_dist is not None and fwd_pos is not None and len(self._waypoint_xy) > 0:
            lx, ly = fwd_pos
            lead_xy = np.array([lx, ly], dtype=np.float64)
            lead_diffs = self._waypoint_xy - lead_xy
            lead_closest_idx = int(np.argmin(np.einsum("ij,ij->i", lead_diffs, lead_diffs)))
            lead_wp = self._reference_path.waypoints[lead_closest_idx]

            lead_dx = lx - lead_wp.x
            lead_dy = ly - lead_wp.y
            lead_psi = float(lead_wp.psi)
            # Exact signed lateral offset of leader from raceline: + is left of raceline, - is right
            leader_e_y = float(-lead_dx * np.sin(lead_psi) + lead_dy * np.cos(lead_psi))

            # Real track bounds at the leader location
            lead_left_wall = float(lead_wp.ub_sm) if lead_wp.ub_sm is not None else (float(lead_wp.ub) if lead_wp.ub is not None else 3.0)
            lead_right_wall = float(abs(lead_wp.lb_sm)) if lead_wp.lb_sm is not None else (float(abs(lead_wp.lb)) if lead_wp.lb is not None else 3.0)

            # True physical open clearances between leader and walls
            left_w = float(max(0.0, lead_left_wall - leader_e_y))
            right_w = float(max(0.0, lead_right_wall + leader_e_y))
        elif fwd_dist is not None and fwd_y_rel is not None:
            leader_e_y = path_e_y + fwd_y_rel
            left_w = float(max(0.0, path_left_wall - leader_e_y))
            right_w = float(max(0.0, path_right_wall + leader_e_y))
        else:
            leader_e_y = None
            left_w = path_left_wall
            right_w = path_right_wall

        fwd_heading_diff = 0.0
        if fwd_heading is not None:
            diff = (fwd_heading - path_psi + np.pi) % (2 * np.pi) - np.pi
            fwd_heading_diff = float(abs(diff))

        return StateContext(
            current_time_sec=now_sec,
            dt=dt,
            pose_x=pose.x,
            pose_y=pose.y,
            pose_theta=pose.theta,
            velocity=v,
            is_colliding=is_colliding,
            time_since_collision=time_since_collision,
            path_deviation=self._compute_path_deviation(),
            path_psi=path_psi,
            path_e_y=path_e_y,
            path_left_wall=path_left_wall,
            path_right_wall=path_right_wall,
            future_min_path_left_wall=future_min_path_left_wall,
            future_min_path_right_wall=future_min_path_right_wall,
            path_kappa=path_kappa,
            future_max_kappa=future_max_kappa,
            is_approaching_straight=is_approaching_straight,
            forward_vehicle_distance=fwd_dist,
            forward_vehicle_speed=fwd_speed,
            forward_vehicle_heading_diff=fwd_heading_diff,
            forward_vehicle_x_rel=fwd_x_rel,
            forward_vehicle_y_rel=fwd_y_rel,
            forward_vehicle_pred_y_rel=fwd_pred_y_rel,
            leader_e_y=leader_e_y,
            forward_vehicle_track_s=fwd_track_s,
            overtake_width_left=left_w,
            overtake_width_right=right_w,
            lidar_forward_clearance=lidar_clearance,
            lidar_range_clearance=range_clearance,
            current_laps=self._current_laps if self._current_laps is not None else 1,
            time_stopped_sec=time_stopped,
            is_in_recovery_cooldown=is_cooldown,
        )

    def _apply_state_params(self, params: MPCStateParams) -> None:
        """Push state-specific MPC parameters into the solver and speed profile."""
        v_max_mps = kmh_to_m_per_sec(params.v_max)

        self._mpc_cfg.v_max = v_max_mps
        self._mpc.update_v_max(v_max_mps)

        self._mpc_cfg.ay_max = params.ay_max
        self._mpc.update_ay_max(params.ay_max)

        self._mpc_cfg.Q = sparse.diags(params.Q)
        self._mpc.update_Q(self._mpc_cfg.Q)

        self._mpc_cfg.R = sparse.diags(params.R)
        self._mpc.update_R(self._mpc_cfg.R)
        self._mpc_cfg.QN = sparse.diags(params.QN)
        self._mpc.update_QN(self._mpc_cfg.QN)

        self._target_lateral_offset = params.lateral_offset
        # Avoid heavy synchronous compute_speed_profile OSQP re-computation during state transitions to eliminate freezes

    # ------------------------------------------------------------------
    # Main control loop
    # ------------------------------------------------------------------

    def _control(self):
        if self._odom is None or self._waypoint_xy is None or len(self._waypoint_xy) == 0:
            return

        try:
            now = self.get_clock().now()
            t = (now - self._t_start).nanoseconds / 1e9
            dt = (now - self._last_t).nanoseconds / 1e9

            self._last_t = now
            self._loop += 1

            # record and print execution stats
            if self.use_stats:
                self._stats.record()

            # self.get_logger().info("loop")
            self._control_rate.sleep()

            if self._loop % 100 == 0:
                # update reference path
                if self._cfg.reference_path.update_by_topic: # type: ignore
                    new_referece_path = self._create_reference_path_from_autoware_trajectory(self._trajectory)
                    if new_referece_path is not None:
                        self._car.reference_path = new_referece_path
                        self._car.update_reference_path(self._car.reference_path)

                def plot_reference_path(car):
                    import matplotlib.pyplot as plt
                    import sys
                    fig, ax = plt.subplots(1, 1)
                    car.reference_path.show(ax)
                    plt.show()
                    sys.exit(1)
                # plot_reference_path(self._car)

            if self.USE_OBSTACLE_AVOIDANCE and self._obstacles_updated:
                self._obstacles_updated = False
                self._map.reset_map()
                filtered_dynamic = self._filter_obstacles_to_corridor(self._dynamic_obstacles)
                self._map.add_obstacles(self._static_obstacles + filtered_dynamic)
                self._reference_path.reset_dynamic_constraints()

            is_colliding = False
            if self._last_colliding_time is not None:
                elapsed_from_last_colliding = (now - self._last_colliding_time).nanoseconds / 1e9
                if elapsed_from_last_colliding < 0.5:
                    is_colliding = True
                else:
                    self._last_colliding_time = None

            pose = odom_to_pose_2d(self._odom) # type: ignore
            v = self._odom.twist.twist.linear.x

            # ---- State-machine tick -------------------------------------------
            prev_state_name = self._state_manager.current_state_name
            ctx = self._build_state_context(dt, is_colliding)
            new_params = self._state_manager.update(ctx)
            if new_params is not None:
                self._apply_state_params(new_params)

            if self._state_manager.current_state_name == "recovery":
                self._last_colliding_time = None  # Consume collision event

            if prev_state_name == "recovery" and self._state_manager.current_state_name != "recovery":
                self._last_recovery_exit_time = (now.nanoseconds / 1e9)
                self._stopped_since = None  # Clear stopped timer to prevent instant re-trigger
                # Instantly reset last control memory to neutral forward motion
                self._last_u[0] = 1.5
                self._last_u[1] = 0.0  # Reset steering memory to neutral!
                self._last_acc = 1.0
                self._current_lateral_offset = 0.0  # Clear lane offset cleanly
                self.get_logger().info("Exited RecoveryState: instant launch, neutral steer & recovery cooldown started")

            # Dynamic interpolation rate: progressive lane change (0.15), gentle glide re-entry (0.05) to prevent wall overshoot at full 38km/h speed
            rate = 0.15 if abs(self._target_lateral_offset) > 0.3 else 0.05
            self._current_lateral_offset += (self._target_lateral_offset - self._current_lateral_offset) * rate

            # Pass TRUE ego vehicle pose to car state without double offset
            self._car.update_states(pose.x, pose.y, pose.theta)

            # Follow state: dynamically adjust v_max to match leader speed
            current_state = self._state_manager.current_state
            if isinstance(current_state, FollowState):
                dynamic_v_max = current_state.get_adjusted_v_max_kmh(ctx)
                v_max_mps = kmh_to_m_per_sec(dynamic_v_max)
                self._mpc.update_v_max(v_max_mps)
                v_ref_list: List[float] = [v_max_mps] * len(self._reference_path.waypoints)
                self._reference_path.set_v_ref(v_ref_list)
                # If leader is close ahead (< 6.5m), freeze current lateral offset to prevent cutting across their line!
                fwd_d = ctx.forward_vehicle_distance
                if fwd_d is not None and fwd_d < 6.5 and abs(self._current_lateral_offset) > 0.3:
                    self._target_lateral_offset = self._current_lateral_offset
                else:
                    self._target_lateral_offset = 0.0
            elif isinstance(current_state, OvertakeState):
                # Continuously adapt overtake offset in real-time based on leader's dynamic motion!
                dynamic_offset = current_state.update_dynamic_offset(ctx)
                self._target_lateral_offset = dynamic_offset

            # Check for control override (e.g., Recovery wait/back)
            override = self._state_manager.get_control_override(ctx)
            if override is not None:
                override_speed, override_steer, override_acc = override
                u = [override_speed, override_steer]
                acc = override_acc

                # If reversing (negative speed), bypass low-pass filter and set positive acceleration magnitude
                if override_speed < 0:
                    acc = abs(override_acc)
                    self._last_acc = acc
                    self._last_u[0] = override_speed
                    self._last_u[1] = override_steer
                else:
                    acc = self._last_acc + (acc - self._last_acc) * self._mpc_cfg.accel_low_pass_gain
                    u[1] = self._last_u[1] + (u[1] - self._last_u[1]) * self._mpc_cfg.steer_low_pass_gain
                    self._last_acc = acc
                    self._last_u[0] = u[0]
                    self._last_u[1] = u[1]

                self._car.drive([v, u[1]])
                self._publish_control_command(now, u, acc, False)
                self._publish_gear_command(now.to_msg(), self._state_manager.current_gear)
                self._sim_logger.log(self._car, u, t)
                self._sim_logger.plot_animation(t, self._loop, self._current_laps, self._lap_times, is_colliding, u, self._mpc, self._car)
                return

            # ---- Control Selection (Hybrid: Pure Pursuit for FollowPath/Follow/Overtake, MPC for fallback) ----
            if current_state.control_mode == ControlMode.PURE_PURSUIT:
                v_target, steer_target = self._compute_pure_pursuit_control(pose, v)
                if isinstance(current_state, FollowState):
                    follow_v_max_mps = kmh_to_m_per_sec(current_state.get_adjusted_v_max_kmh(ctx))
                    v_target = min(v_target, follow_v_max_mps)
                elif isinstance(current_state, OvertakeState):
                    # Oriented Bounding Box (OBB) Rear-Corner Collision Guard:
                    # Vehicle rectangular geometry: width 1.30m (half 0.65m), length 1.60m (half 0.80m).
                    # If ego is directly behind the leader's rear corners (0 < x_rel < 4.0m, |y_rel| < 1.35m),
                    # ego must match leader speed during the lateral transition to NEVER clip the rear bumper corner!
                    fwd_d = ctx.forward_vehicle_distance
                    fwd_x = ctx.forward_vehicle_x_rel
                    fwd_y = ctx.forward_vehicle_y_rel
                    fwd_spd = ctx.forward_vehicle_speed if ctx.forward_vehicle_speed is not None else 6.0

                    is_in_rear_corner_zone = (
                        fwd_x is not None and 0.0 < fwd_x < 4.0
                        and (fwd_y is None or abs(fwd_y) < 1.35)
                        and abs(self._current_lateral_offset) < 0.90
                    )

                    if is_in_rear_corner_zone:
                        # Smooth transition speed while opening lateral gap past rear corners
                        v_target = min(kmh_to_m_per_sec(38.0), fwd_spd + 0.8)
                    elif abs(ctx.path_kappa) >= 0.070:
                        v_target = kmh_to_m_per_sec(24.0)
                    else:
                        v_target = kmh_to_m_per_sec(38.0)
                u = [v_target, steer_target]
                max_delta = steer_target
            else:
                with self._stats.time_block("control"):
                    u, max_delta = self._mpc.get_control()

            # FollowState uses dynamic following speed; OvertakeState uses full 38 km/h speed (24 km/h in hairpins)
            if isinstance(current_state, OvertakeState):
                fwd_d = ctx.forward_vehicle_distance
                fwd_x = ctx.forward_vehicle_x_rel
                fwd_y = ctx.forward_vehicle_y_rel
                fwd_spd = ctx.forward_vehicle_speed if ctx.forward_vehicle_speed is not None else 6.0

                is_in_rear_corner_zone = (
                    fwd_x is not None and 0.0 < fwd_x < 4.0
                    and (fwd_y is None or abs(fwd_y) < 1.35)
                    and abs(self._current_lateral_offset) < 0.90
                )

                if is_in_rear_corner_zone:
                    v_max_mps = min(kmh_to_m_per_sec(38.0), fwd_spd + 0.8)
                elif abs(ctx.path_kappa) >= 0.070:
                    v_max_mps = kmh_to_m_per_sec(24.0)
                else:
                    v_max_mps = kmh_to_m_per_sec(38.0)

                self._mpc.update_v_max(v_max_mps)
                v_ref_list: List[float] = [v_max_mps] * len(self._reference_path.waypoints)
                self._reference_path.set_v_ref(v_ref_list)
                u[0] = v_max_mps
            elif self._ref_vel_configulator is not None and not isinstance(current_state, FollowState):
                ref_vel_mps = self._ref_vel_configulator.get_ref_vel(self._mpc.model.wp_id)
                ref_vel_mps_capped = min(ref_vel_mps, self._mpc_cfg.v_max)
                self._mpc.update_v_max(ref_vel_mps_capped)
                v_ref = [ref_vel_mps_capped] * len(self._reference_path.waypoints)
                self._reference_path.set_v_ref(v_ref)

            # override by brake command if control is disabled
            if not self._enable_control:
                last_v_cmd = self._last_u[0]
                if last_v_cmd < 0.5:
                    u[0] = 0.0
                else:
                    decel_v = last_v_cmd + self._mpc_cfg.a_min * dt
                    u[0] = np.clip(decel_v, 0.0, self._mpc_cfg.v_max)

            if len(u) == 0:
                self.get_logger().error("No control signal", throttle_duration_sec=1)
                u = [0.0, 0.0]

            acc = 0.
            bug_acc_enabled = False
            if override is not None:
                acc = override[2]
            elif isinstance(current_state, OvertakeState):
                # Full throttle overtake acceleration (3.5 m/s^2)
                acc = 1.5
            elif current_state.control_mode == ControlMode.PURE_PURSUIT:
                acc = self.KP * (u[0] - v)
                acc = np.clip(acc, self._mpc_cfg.a_min, 1.5)
            elif self.USE_BUG_ACC:
                def deg2rad(deg):
                    return deg * np.pi / 180.0

                if abs(v) > kmh_to_m_per_sec(44.0) or \
                 (abs(v) > kmh_to_m_per_sec(38.0) and abs(max_delta) > deg2rad(12.0)):
                    bug_acc_enabled = False
                    acc = self._mpc_cfg.a_min / 3.0 * 2.0
                    self._pred_marker_color = RED
                elif abs(v) > kmh_to_m_per_sec(41.0) or abs(u[1]) > deg2rad(10.0):
                    bug_acc_enabled = False
                    acc = min(self._mpc_cfg.a_max, 1.0)
                    self._pred_marker_color = YELLOW
                else:
                    bug_acc_enabled = True
                    acc = 500.0
                    self._pred_marker_color = CYAN
            else:
                acc = self.KP * (u[0] - v)
                # print(f"v: {v}, u[0]: {u[0]}, acc: {acc}")
                acc = np.clip(acc, self._mpc_cfg.a_min, 1.5)

            # FollowState: Limit positive acceleration to prevent rear-end collisions due to latency
            if isinstance(current_state, FollowState):
                acc = float(np.clip(acc, self._mpc_cfg.a_min, 0.5))  # max 0.5 m/s²

            # Global clamp (allow 3.5 m/s^2 in OvertakeState for decisive passing)
            max_allowed_acc = 3.5 if isinstance(current_state, OvertakeState) else 1.5
            if not bug_acc_enabled:
                acc = float(np.clip(acc, self._mpc_cfg.a_min, max_allowed_acc))

            # apply steer rate limiter to prevent excessive jerking while maintaining sharp cornering capability
            max_delta_steer = 2.0 * dt
            u[1] = float(np.clip(u[1], self._last_u[1] - max_delta_steer, self._last_u[1] + max_delta_steer))

            # apply low pass filter to control signal
            acc = self._last_acc + (acc - self._last_acc) * self._mpc_cfg.accel_low_pass_gain
            u[1] = self._last_u[1] + (u[1] - self._last_u[1]) * self._mpc_cfg.steer_low_pass_gain

            self._last_acc = acc
            self._last_u[0] = u[0]
            self._last_u[1] = u[1]

            # update car state (use v for feedback actual speed)
            self._car.drive([v, u[1]])

            # Publish control command & gear command
            self._publish_control_command(now, u, acc, bug_acc_enabled)
            self._publish_gear_command(now.to_msg(), self._state_manager.current_gear)

            # Log states
            self._sim_logger.log(self._car, u, t)
            self._sim_logger.plot_animation(t, self._loop, self._current_laps, self._lap_times, is_colliding, u, self._mpc, self._car)

            # 約 0.25 秒ごとに予測結果を表示
            if (self._mpc.current_prediction is not None) and (self._loop % (self._mpc_cfg.control_rate // 4) == 0):
                self._publish_mpc_pred_marker(self._mpc.current_prediction[0], self._mpc.current_prediction[1]) # type: ignore
        except Exception as e:
            self.get_logger().error(f"Error in _control loop (continuing execution): {e}")

    def run(self) -> None:
        try:
            self._wait_until_clock_received()
            self._wait_until_odom_received()
            self._wait_until_trajectory_received(timeout=5.0)
            self._wait_until_path_constraints_received(timeout=5.0)
        except Exception as e:
            self.get_logger().warn(f"Topic wait warning (continuing node execution): {e}")

        # wait until odom is received to avoid NoneType AttributeError
        while rclpy.ok() and self._odom is None:
            self.get_logger().info("Waiting for odometry message before starting control loop...")
            self.get_clock().sleep_for(rclpy.time.Duration(seconds=0.1))

        # initialize car states
        pose = odom_to_pose_2d(self._odom) # type: ignore
        self._car.update_states(pose.x, pose.y, pose.theta)
        self._car.update_reference_path(self._car.reference_path)

        if self._ref_vel_configulator is None:
            self._publish_ref_path_marker(self._car.reference_path)

        self._pred_marker_color = CYAN

        # for i in range(10):
        #     self._obstacle_manager.push_next_obstacle()

        # initialize control states
        self._control_rate = self.create_rate(self._mpc_cfg.control_rate)
        self._sim_logger = SimulationLogger(
            self.get_logger(),
            self._car.temporal_state.x, self._car.temporal_state.y, self._cfg.sim_logger.animation_enabled, self.SHOW_PLOT_ANIMATION, self.PLOT_RESULTS, self.ANIMATION_INTERVAL) # type: ignore

        self._loop = 0
        self._last_acc = 0.0
        self._last_u = np.array([0.0, 0.0])
        self._t_start = self.get_clock().now()
        self._last_t = self._t_start

        self.get_logger().info("----------------------")
        self.get_logger().info("START!")
        self.get_logger().info("----------------------")

        while rclpy.ok() and (not self._sim_logger.stop_requested()):
            self._control()

    def stop(self):
        # Wait for stopping
        self.get_logger().warn("----------------------")
        self.get_logger().warn("Stopping...")
        self.get_logger().warn("----------------------")
        timeout_time = self.get_clock().now() + rclpy.time.Duration(seconds=5)
        while self._odom.twist.twist.linear.x > 0.1 and self.get_clock().now() < timeout_time:
            self._enable_control = False
            self._control()

        # Publish zero command to stop the car completely
        zero_cmd = self._create_ackerman_control_command(self.get_clock().now(), [0.0, 0.0], 0.0, False)
        self._command_pub.publish(zero_cmd)

        self.get_logger().warn(">> Stop Completed!")

        # show results
        self._sim_logger.show_results(self._current_laps, self._lap_times, self._car)

    @classmethod
    def in_pkg_share(cls, file_path: str) -> str:
        return cls.PKG_PATH + file_path
