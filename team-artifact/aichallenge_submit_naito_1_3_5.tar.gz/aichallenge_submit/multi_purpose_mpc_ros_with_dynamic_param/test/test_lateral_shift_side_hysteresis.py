"""Unit tests for LateralShiftSideFilter (pure Python, no rclpy)."""

import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import LateralShiftSideFilter

TICK = 1.0 / 40.0  # control loop period [s] (config.yaml: control_rate 40.0)

# Ticks that clearly clear the dwell (one and a half times it), so no test sits
# on the boundary where float rounding decides the outcome. Derived from the
# constant so retuning LATERAL_SHIFT_DWELL_SEC does not break these tests.
COMMIT_TICKS = int(1.5 * states.LATERAL_SHIFT_DWELL_SEC / TICK) + 1

# Ticks that stay comfortably inside the dwell.
UNDER_DWELL_TICKS = max(1, int(0.5 * states.LATERAL_SHIFT_DWELL_SEC / TICK))


def widths(diff, base=1.7):
    """Left/right free widths whose difference is ``diff``."""
    return base + diff / 2.0, base - diff / 2.0


def feed(filt, diff, ticks, t0=0.0):
    """Feed a constant width difference for ``ticks`` control cycles.

    Returns (side, next_time).
    """
    left, right = widths(diff)
    side = filt.side
    for i in range(ticks):
        side = filt.update(left, right, t0 + i * TICK)
    return side, t0 + ticks * TICK


def committed_left(filt, t0=0.0):
    """Drive the filter into a committed "left" and return the next time."""
    side, t = feed(filt, +0.5, COMMIT_TICKS, t0)
    assert side == "left"
    return t


def test_starts_on_the_centerline():
    assert LateralShiftSideFilter().side == "none"


def test_does_not_commit_before_the_dwell_time():
    side, _ = feed(LateralShiftSideFilter(), +0.5, UNDER_DWELL_TICKS)
    assert side == "none"


def test_commits_once_the_dwell_time_elapses():
    side, _ = feed(LateralShiftSideFilter(), +0.5, COMMIT_TICKS)
    assert side == "left"


def test_commits_to_the_right_for_a_negative_difference():
    side, _ = feed(LateralShiftSideFilter(), -0.5, COMMIT_TICKS)
    assert side == "right"


def test_latches_inside_the_band_between_exit_and_enter():
    """0.2 <= |diff| <= 0.4 holds the current side, however long it lasts."""
    filt = LateralShiftSideFilter()
    t = committed_left(filt)
    side, _ = feed(filt, +0.3, 20, t)
    assert side == "left"


def test_releases_to_the_centerline_below_the_exit_threshold():
    filt = LateralShiftSideFilter()
    t = committed_left(filt)
    side, _ = feed(filt, +0.1, COMMIT_TICKS, t)
    assert side == "none"


def test_flips_straight_to_the_opposite_side_without_passing_through_none():
    filt = LateralShiftSideFilter()
    t = committed_left(filt)

    left, right = widths(-0.5)
    seen = [filt.update(left, right, t + i * TICK) for i in range(COMMIT_TICKS)]

    assert seen[-1] == "right"
    assert "none" not in seen  # "left" is held until "right" commits


def test_alternating_noise_never_commits():
    """A sign that flips every tick must not reach the dwell time."""
    filt = LateralShiftSideFilter()
    for i in range(40):
        left, right = widths(+0.5 if i % 2 == 0 else -0.5)
        assert filt.update(left, right, i * TICK) == "none"


def test_returns_to_the_centerline_when_the_leader_disappears():
    """_compute_v2x_overtake_corridor returns (0, 0, 0) with no vehicle detected."""
    filt = LateralShiftSideFilter()
    t = committed_left(filt)

    side = "left"
    for i in range(COMMIT_TICKS):
        side = filt.update(0.0, 0.0, t + i * TICK)
    assert side == "none"


def test_thresholds_are_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.LATERAL_SHIFT_ENTER_DIFF_M
    try:
        states.LATERAL_SHIFT_ENTER_DIFF_M = 1.0
        side, _ = feed(LateralShiftSideFilter(), +0.5, 10)
        assert side == "none"

        states.LATERAL_SHIFT_ENTER_DIFF_M = 0.4
        side, _ = feed(LateralShiftSideFilter(), +0.5, 10)
        assert side == "left"
    finally:
        states.LATERAL_SHIFT_ENTER_DIFF_M = original


def test_dwell_is_measured_in_time_not_ticks():
    """A single call after the dwell window commits, regardless of tick count."""
    filt = LateralShiftSideFilter()
    left, right = widths(+0.5)

    assert filt.update(left, right, 0.0) == "none"
    assert filt.update(left, right, 0.5) == "left"
