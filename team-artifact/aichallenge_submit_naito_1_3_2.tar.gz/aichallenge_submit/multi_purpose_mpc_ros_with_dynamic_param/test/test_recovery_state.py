"""Unit tests for RecoveryState early exit and boost (pure Python, no rclpy)."""

import numpy as np
import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import (
    GEAR_DRIVE,
    GEAR_REVERSE,
    RecoveryState,
    StateContext,
)

TICK = 1.0 / 40.0  # control loop period [s] (config.yaml: control_rate 40.0)

# Derived from the constants so retuning the thresholds does not break these tests.
# "Not aligned yet": well outside both thresholds.
SKEWED = dict(
    heading_deg=3.0 * states.RECOVERY_ALIGNED_HEADING_DEG,
    e_y=3.0 * states.RECOVERY_ALIGNED_E_Y_M,
)
# "Aligned": comfortably inside both thresholds.
ALIGNED = dict(
    heading_deg=0.5 * states.RECOVERY_ALIGNED_HEADING_DEG,
    e_y=0.5 * states.RECOVERY_ALIGNED_E_Y_M,
)


def make_ctx(t, heading_deg=30.0, e_y=2.0, publish_boost=None):
    """Context with the path running along x, so pose_theta IS the heading error."""
    return StateContext(
        current_time_sec=t,
        dt=TICK,
        pose_x=0.0,
        pose_y=0.0,
        pose_theta=np.deg2rad(heading_deg),
        velocity=0.0,
        is_colliding=False,
        path_psi=0.0,
        path_e_y=e_y,
        publish_boost=publish_boost,
    )


def entered(e_y=2.0, **kwargs):
    """A RecoveryState that has just been entered."""
    state = RecoveryState()
    state.on_enter(make_ctx(0.0, e_y=e_y, **kwargs))
    return state


def run(state, ticks, t0=0.0, **ctx_kw):
    """Tick check_transition; return (next_state_name_or_None, ticks_consumed)."""
    for i in range(ticks):
        result = state.check_transition(make_ctx(t0 + i * TICK, **ctx_kw))
        if result is not None:
            return result, i + 1
    return None, ticks


def advance_to_phase(state, phase, max_ticks=200, **ctx_kw):
    """Tick until the state reaches ``phase``; return the next time."""
    for i in range(max_ticks):
        if state._phase == phase:
            return i * TICK
        assert state.check_transition(make_ctx(i * TICK, **ctx_kw)) is None
    raise AssertionError(f"never reached phase {phase!r}")


# --- gear / speed / acceleration ------------------------------------------

def test_back_phase_commands_reverse_gear_and_negative_speed():
    state = entered()
    advance_to_phase(state, "back", **SKEWED)
    speed, _, acc = state.compute_control_override(make_ctx(0.0, **SKEWED))
    assert state.gear == GEAR_REVERSE
    assert speed == state.RECOVERY_BACK_TURN_SPEED_MPS < 0
    assert acc == state.RECOVERY_BACK_ACCEL_MPSS


def test_forward_phase_commands_drive_gear_and_positive_speed():
    state = entered()
    advance_to_phase(state, "forward_turn", **SKEWED)
    speed, _, acc = state.compute_control_override(make_ctx(0.0, **SKEWED))
    assert state.gear == GEAR_DRIVE
    assert speed == state.RECOVERY_FORWARD_TURN_SPEED_MPS > 0
    assert acc == state.RECOVERY_FORWARD_ACCEL_MPSS


def test_reverses_on_the_very_first_tick_after_entering():
    """No `wait` phase: the entry tick already commands REVERSE and negative speed.

    StateManager does not call check_transition on the tick it enters a state, so a
    `wait` phase would leak one tick of (0, 0, 0) + GEAR_DRIVE before reversing.
    """
    state = entered()

    assert state._phase == "back"
    assert state.gear == GEAR_REVERSE

    speed, _, acc = state.compute_control_override(make_ctx(0.0, **SKEWED))
    assert speed < 0.0
    assert acc > 0.0


# --- steering from the heading error ---------------------------------------

def steer_in(phase, heading_deg):
    state = entered()
    advance_to_phase(state, phase, **SKEWED)
    _, steer, _ = state.compute_control_override(
        make_ctx(0.0, heading_deg=heading_deg, e_y=2.0))
    return steer


def test_back_steers_in_the_same_direction_as_the_heading_error():
    """Reversing (v < 0): psi_dot = v/L * tan(delta), so delta shares e_psi's sign."""
    assert steer_in("back", +20.0) > 0.0
    assert steer_in("back", -20.0) < 0.0


def test_forward_steers_opposite_to_the_heading_error():
    """Driving forward (v > 0): the sign flips to keep converging on the path."""
    assert steer_in("forward_turn", +20.0) < 0.0
    assert steer_in("forward_turn", -20.0) > 0.0


def test_steer_is_proportional_to_the_heading_error_below_the_lock():
    heading_deg = 10.0
    expected = states.RECOVERY_STEER_K * np.deg2rad(heading_deg)
    assert expected < RecoveryState.RECOVERY_STEER_LOCK_RAD  # guard: below the clip

    assert steer_in("back", heading_deg) == pytest.approx(expected)
    assert steer_in("forward_turn", heading_deg) == pytest.approx(-expected)


def test_steer_clips_to_the_lock_for_large_heading_errors():
    lock = RecoveryState.RECOVERY_STEER_LOCK_RAD
    assert steer_in("back", +90.0) == pytest.approx(+lock)
    assert steer_in("forward_turn", +90.0) == pytest.approx(-lock)


def test_steers_straight_when_already_parallel_to_the_path():
    """Wedged head-on into a wall (e_psi ~ 0): back straight out, no steering."""
    assert steer_in("back", 0.0) == pytest.approx(0.0)
    assert steer_in("forward_turn", 0.0) == pytest.approx(0.0)


def test_steer_gain_is_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.RECOVERY_STEER_K
    try:
        states.RECOVERY_STEER_K = 0.0
        assert steer_in("back", +20.0) == pytest.approx(0.0)

        states.RECOVERY_STEER_K = 0.5
        assert steer_in("back", +20.0) == pytest.approx(0.5 * np.deg2rad(20.0))
    finally:
        states.RECOVERY_STEER_K = original


# --- early exit -----------------------------------------------------------

def test_returns_to_follow_path_almost_immediately_when_already_aligned():
    state = entered(e_y=0.5)
    result, ticks = run(state, 200, **ALIGNED)
    assert result == "follow_path"
    assert ticks <= 5  # ~125 ms, versus the 2.0 s timeout (80 ticks)


def test_heading_alone_does_not_trigger_the_early_exit():
    state = entered()
    result, _ = run(state, 20, heading_deg=5.0, e_y=2.0)
    assert result is None


def test_lateral_offset_alone_does_not_trigger_the_early_exit():
    state = entered()
    result, _ = run(state, 20, heading_deg=30.0, e_y=0.5)
    assert result is None


def test_falls_back_to_the_timeout_when_never_aligned():
    state = entered()
    timeout = (
        RecoveryState.BACK_DURATION_TIME_SEC
        + RecoveryState.FORWARD_DURATION_TIME_SEC
    )
    result, ticks = run(state, 400, **SKEWED)
    assert result == "follow_path"
    assert ticks * TICK == pytest.approx(timeout, abs=3 * TICK)


def test_each_phase_gets_its_own_duration():
    """Leaving `back` early must not lengthen or shorten `forward_turn`."""
    state = entered(e_y=0.5)

    # Aligned -> back ends after a single tick.
    t = advance_to_phase(state, "forward_turn", **ALIGNED)
    assert t <= 3 * TICK

    # Now skewed again: forward_turn must still get its full duration.
    result, ticks = run(state, 400, t0=t, **SKEWED)
    assert result == "follow_path"
    assert ticks * TICK == pytest.approx(
        RecoveryState.FORWARD_DURATION_TIME_SEC, abs=2 * TICK
    )


def test_alignment_thresholds_are_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.RECOVERY_ALIGNED_HEADING_DEG
    skewed_heading = SKEWED["heading_deg"]        # outside the default threshold
    near_center_e_y = ALIGNED["e_y"]              # inside the lateral threshold
    try:
        states.RECOVERY_ALIGNED_HEADING_DEG = 2.0 * skewed_heading
        result, _ = run(entered(), 20, heading_deg=skewed_heading, e_y=near_center_e_y)
        assert result == "follow_path"

        states.RECOVERY_ALIGNED_HEADING_DEG = original
        result, _ = run(entered(), 20, heading_deg=skewed_heading, e_y=near_center_e_y)
        assert result is None
    finally:
        states.RECOVERY_ALIGNED_HEADING_DEG = original


# --- boost ----------------------------------------------------------------

def test_on_exit_turns_boost_on():
    published = []
    state = entered()
    state.on_exit(make_ctx(1.0, publish_boost=published.append))
    assert published == [states.RECOVERY_BOOST_VALUE]


def test_on_exit_without_a_boost_publisher_does_not_raise():
    state = entered()
    state.on_exit(make_ctx(1.0, publish_boost=None))
