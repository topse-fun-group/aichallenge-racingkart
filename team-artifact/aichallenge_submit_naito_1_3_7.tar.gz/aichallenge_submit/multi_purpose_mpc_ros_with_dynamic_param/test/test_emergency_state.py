"""Unit tests for EmergencyState (pure Python, no rclpy).

緊急回避 (ADR-059) は手動トピックでのみ発火する独立した脱出モード。
RecoveryState とはコードも定数も共有しないので、このファイルも独立させる。
"""

import numpy as np
import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import (
    ControlMode,
    EmergencyState,
    GEAR_REVERSE,
    StateContext,
)


def make_ctx(t=0.0, v=0.0, dt=0.025, e_y=0.0, e_psi=0.0):
    return StateContext(
        current_time_sec=t,
        dt=dt,
        state_id="ego",
        pose_x=0.0,
        pose_y=0.0,
        pose_theta=e_psi,      # path_psi=0 なので pose_theta がそのまま姿勢誤差
        velocity=v,
        is_colliding=False,
        path_psi=0.0,
        path_e_y=e_y,
    )


def entered(t=0.0):
    st = EmergencyState()
    st.on_enter(make_ctx(t=t))
    return st


def drive(st, v, seconds, t0=0.0, dt=0.025):
    """速度 v [m/s] で seconds 秒ぶん tick を回し、最後の返り値を返す。"""
    out = None
    n = int(round(seconds / dt))
    for i in range(n):
        out = st.check_transition(make_ctx(t=t0 + (i + 1) * dt, v=v, dt=dt))
        if out is not None:
            return out
    return out


# --- 状態としての性質 -------------------------------------------------------

def test_the_state_reverses_under_direct_override():
    st = EmergencyState()
    assert st.name == "emergency"
    assert st.control_mode is ControlMode.OVERRIDE
    assert st.gear == GEAR_REVERSE


def test_the_override_commands_a_reverse():
    """速度は負、加速度は正。"""
    speed, _, acc = entered().compute_control_override(make_ctx(v=-2.0))
    assert speed < 0.0
    assert acc > 0.0


def test_the_params_are_conservative():
    """override 中は使われないが、遷移時に適用されるので暴れる値を返さない。"""
    p = EmergencyState().get_params()
    assert p.v_max <= 20.0
    assert p.lateral_offset == 0.0


# --- 離脱条件（実際に後退した距離で測る） -----------------------------------

def test_it_keeps_reversing_before_the_target_distance():
    st = entered()
    # 2m ぶん後退しただけでは抜けない
    assert drive(st, v=-2.0, seconds=1.0) is None


def test_it_returns_to_follow_path_after_backing_the_target_distance():
    """本命。実際に 3m 後退したら通常走行へ返す。"""
    st = entered()
    assert drive(st, v=-2.0, seconds=2.0) == "follow_path"


def test_forward_coasting_does_not_count_as_backing():
    """回帰防止。走行中に発行されると減速までに前へ進むが、それは数えない。

    実測 (20260919-030622): 22km/h で発行したところ、突入位置からの直線距離で
    測っていたため 0.48 秒・前進のまま reason=backed で抜けていた。
    """
    st = entered()
    # 6.1 m/s (22km/h) で 3 秒前進 = 18m 進んでも離脱しない
    assert drive(st, v=+6.1, seconds=3.0) is None
    # その後きちんと 3m 後退してはじめて離脱する
    assert drive(st, v=-2.0, seconds=1.0, t0=3.0) is None
    assert drive(st, v=-2.0, seconds=1.0, t0=4.0) == "follow_path"


def test_the_backed_distance_accumulates_across_ticks():
    st = entered()
    assert drive(st, v=-1.0, seconds=1.0) is None          # 1m
    assert drive(st, v=-1.0, seconds=1.0, t0=1.0) is None  # 計 2m
    assert drive(st, v=-1.0, seconds=1.2, t0=2.0) == "follow_path"  # 計 3.2m


def test_a_stationary_vehicle_accumulates_nothing():
    st = entered()
    assert drive(st, v=0.0, seconds=3.0) is None


def test_a_wedged_vehicle_still_leaves_on_the_timeout():
    """車体が噛んで 1mm も動けなくても、保険で必ず抜ける。"""
    st = entered()
    t = states.EMERGENCY_TIMEOUT_SEC
    assert st.check_transition(make_ctx(t=t - 0.1, v=0.0)) is None
    assert st.check_transition(make_ctx(t=t, v=0.0)) == "follow_path"


def test_check_transition_is_inert_before_on_enter():
    """on_enter を通っていない状態では何も返さない。"""
    assert EmergencyState().check_transition(make_ctx(t=99.0, v=-9.0)) is None


def test_on_exit_clears_the_entry_latch():
    st = entered()
    st.on_exit(make_ctx(t=1.0))
    assert st.check_transition(make_ctx(t=99.0, v=-9.0)) is None


def test_re_entering_resets_the_accumulator():
    """2 回目の発行で、前回の後退分が残っていないこと。"""
    st = entered()
    drive(st, v=-2.0, seconds=1.0)      # 2m 積む
    st.on_exit(make_ctx(t=1.0))
    st.on_enter(make_ctx(t=10.0))
    assert drive(st, v=-2.0, seconds=1.0, t0=10.0) is None   # 2m では抜けない


# --- ROS パラメータ経由の調整 -----------------------------------------------

def test_the_distance_is_read_from_module_globals():
    """setattr(states, ...) で ROS パラメータが効くこと。"""
    original = states.EMERGENCY_BACK_DISTANCE_M
    try:
        states.EMERGENCY_BACK_DISTANCE_M = 1.0
        st = entered()
        assert drive(st, v=-2.0, seconds=0.6) == "follow_path"
    finally:
        states.EMERGENCY_BACK_DISTANCE_M = original




# --- 既存への影響がないこと -------------------------------------------------

def test_the_request_flag_defaults_to_false():
    """既存の StateContext 生成箇所を壊さない。自動では絶対に立たない。"""
    assert make_ctx().emergency_request is False


# --- 後退中の操舵（経路の中心・姿勢へ戻す） ---------------------------------
#
# 後退では舵角の効き方が前進と逆になる。自転車モデル (後軸基準、v<0):
#   e_y_dot = v sin(e_psi)      -> e_y>0 を減らすには e_psi>0 (機首を左)
#   psi_dot = (v/L) tan(delta)  -> e_psi を増やすには delta<0 (右に切る)
# したがって「左にいるほど右へ切る」。この符号は破ってはいけない契約なので、
# 復帰の符号反転 (ADR-044) と同じ轍を踏まないようここで固定する。

def steer_for(e_y=0.0, e_psi=0.0, v=-2.0):
    return entered().compute_control_override(
        make_ctx(v=v, e_y=e_y, e_psi=e_psi))[1]


def test_being_left_of_the_path_steers_right_while_reversing():
    """本命の符号契約。経路の左にいるなら後退中は右へ切る。"""
    assert steer_for(e_y=+1.0) < 0.0


def test_being_right_of_the_path_steers_left_while_reversing():
    assert steer_for(e_y=-1.0) > 0.0


def test_a_nose_left_attitude_steers_left_to_straighten():
    """横偏差ゼロで機首だけ左を向いているなら、後退中は左へ切って戻す。"""
    assert steer_for(e_psi=+0.3) > 0.0


def test_a_nose_right_attitude_steers_right_to_straighten():
    assert steer_for(e_psi=-0.3) < 0.0


def test_being_on_the_centerline_and_aligned_needs_no_steer():
    assert steer_for() == pytest.approx(0.0)


def test_the_steer_is_symmetric():
    assert steer_for(e_y=+1.0, e_psi=+0.2) == pytest.approx(-steer_for(e_y=-1.0, e_psi=-0.2))


def test_the_steer_grows_with_the_lateral_error():
    """飽和域の外で比較する（大きい横偏差は上限に張り付くため）。"""
    assert abs(steer_for(e_y=+0.2)) > abs(steer_for(e_y=+0.05))


def test_the_steer_is_capped():
    """復帰の 1.55rad (89 度) のような実用外の大舵角は出さない。"""
    for e_y, e_psi in ((+10.0, +3.0), (-10.0, -3.0), (+10.0, -3.0)):
        assert abs(steer_for(e_y=e_y, e_psi=e_psi)) <= states.EMERGENCY_STEER_MAX_RAD
    assert states.EMERGENCY_STEER_MAX_RAD < 1.0


def test_the_target_attitude_is_capped():
    """横偏差が大きくても目標姿勢は 30 度で頭打ち。"""
    big = steer_for(e_y=+100.0)
    same = steer_for(e_y=+ states.EMERGENCY_HEADING_MAX_RAD / states.EMERGENCY_HEADING_FROM_EY)
    assert big == pytest.approx(same)


def test_no_steer_while_still_coasting_forward():
    """前進の惰性が残っている間は舵角の効き方が逆なので切らない。"""
    assert steer_for(e_y=+1.5, e_psi=+0.3, v=+5.0) == pytest.approx(0.0)
    assert steer_for(e_y=+1.5, e_psi=+0.3, v=0.0) == pytest.approx(0.0)


def test_the_gains_are_read_from_module_globals():
    original = states.EMERGENCY_STEER_K
    try:
        states.EMERGENCY_STEER_K = 0.0
        assert steer_for(e_y=+1.0, e_psi=+0.3) == pytest.approx(0.0)
    finally:
        states.EMERGENCY_STEER_K = original


def test_it_converges_toward_the_centerline_over_three_metres():
    """自転車モデルで回して、実際に中心・姿勢へ寄ることを確認する。"""
    L, v, dt = 1.087, -2.0, 0.02
    e_y, e_psi, travelled = 1.0, 0.0, 0.0
    st = entered()
    while travelled < states.EMERGENCY_BACK_DISTANCE_M:
        delta = st.compute_control_override(make_ctx(v=v, e_y=e_y, e_psi=e_psi))[1]
        e_y += v * np.sin(e_psi) * dt
        e_psi += (v / L) * np.tan(delta) * dt
        travelled += abs(v) * dt
    assert abs(e_y) < 0.4          # 1.0m -> 0.4m 未満
    assert abs(e_psi) < np.deg2rad(20.0)


# --- 後半は姿勢合わせを優先する (経路と平行に戻す) --------------------------

def test_the_target_attitude_decays_as_the_backing_completes():
    """本命。横偏差が同じでも、後退が進むほど舵角は姿勢合わせ側へ寄る。

    これが無いと目標姿勢が横偏差に比例したままなので、横偏差が残る限り
    **車体が斜めのまま終わる**（実測で「経路と平行にならない」と報告された）。
    """
    early = EmergencyState(); early.on_enter(make_ctx())
    late = EmergencyState(); late.on_enter(make_ctx())
    late._backed_m = states.EMERGENCY_BACK_DISTANCE_M      # 進捗 100%
    c = make_ctx(v=-2.0, e_y=0.2, e_psi=0.0)
    # 進捗 100% では目標姿勢が 0 になるので、姿勢が揃っていれば舵角も 0
    assert abs(early.compute_control_override(c)[1]) > 0.0
    assert late.compute_control_override(c)[1] == pytest.approx(0.0)


def test_the_align_phase_still_corrects_attitude():
    """姿勢合わせ区間でも、姿勢が傾いていればちゃんと戻す。"""
    st = EmergencyState(); st.on_enter(make_ctx())
    st._backed_m = states.EMERGENCY_BACK_DISTANCE_M
    assert st.compute_control_override(make_ctx(v=-2.0, e_y=0.0, e_psi=+0.3))[1] > 0.0


def test_it_ends_parallel_to_the_path():
    """3m 後退したあと、横偏差も姿勢もほぼ経路に一致すること。

    40Hz の離散制御・v=-3m/s で回す（距離基準なので後退速度にほぼ依存しない）。
    """
    L, v, dt = 1.087, -3.0, 1.0 / 40.0
    for e_y0, e_psi0 in ((1.0, 0.0), (-1.0, 0.0), (0.0, 0.3), (1.5, -0.2), (2.0, 0.3)):
        st = EmergencyState(); st.on_enter(make_ctx())
        e_y, e_psi, travelled = e_y0, e_psi0, 0.0
        while travelled < states.EMERGENCY_BACK_DISTANCE_M:
            ctx = make_ctx(v=v, e_y=e_y, e_psi=e_psi, dt=dt)
            delta = st.compute_control_override(ctx)[1]
            st.check_transition(ctx)          # 後退距離を積ませる
            e_y += v * np.sin(e_psi) * dt
            e_psi += (v / L) * np.tan(delta) * dt
            travelled += abs(v) * dt
        assert abs(e_y) < 0.3, f"e_y={e_y:.2f} (初期 {e_y0})"
        assert abs(e_psi) < np.deg2rad(8.0), f"e_psi={np.degrees(e_psi):.0f}deg (初期 {e_y0})"
