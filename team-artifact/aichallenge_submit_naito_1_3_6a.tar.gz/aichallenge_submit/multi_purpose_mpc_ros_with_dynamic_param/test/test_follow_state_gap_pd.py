"""Unit tests for FollowState gap PD control (pure Python, no rclpy)."""

import numpy as np
import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import FollowState, StateContext


def make_ctx(
    *,
    gap=None,
    v_ego=5.0,
    v_lead=5.0,
    overtake_width=0.0,
    forward_distance=None,
    lateral=0.0,
):
    """Build a StateContext for the follow-distance PD.

    ``gap`` is the bumper-to-bumper distance; it is converted to the
    centre-to-centre ``forward_vehicle_distance`` the detector actually
    reports. Pass ``forward_distance`` instead to set it directly.
    """
    if forward_distance is None and gap is not None:
        forward_distance = gap + states.VEHICLE_LENGTH

    return StateContext(
        current_time_sec=0.0,
        dt=0.02,
        state_id="ego",
        pose_x=0.0,
        pose_y=0.0,
        pose_theta=0.0,
        velocity=v_ego,
        is_colliding=False,
        forward_vehicle_distance=forward_distance,
        forward_vehicle_speed=None if forward_distance is None else v_lead,
        min_forward_overtake_width=overtake_width,
        forward_vehicle_lateral=lateral,
    )


def v_cmd(**kwargs):
    return FollowState().get_adjusted_v_max_mps(make_ctx(**kwargs))


WIDE_CORRIDOR = states.MIN_OVERTAKE_WIDTH_M + 1.0
NARROW_CORRIDOR = states.MIN_OVERTAKE_WIDTH_M - 0.1


def target(overtake_width=0.0):
    """The desired bumper-to-bumper gap for this corridor width."""
    return (states.D0_M if overtake_width >= states.MIN_OVERTAKE_WIDTH_M
            else states.FOLLOW_TARGET_DISTANCE_M)


# --- the PD itself ---------------------------------------------------------

def test_settles_at_target_gap_with_no_steady_state_error():
    """At the target gap and matched speed, command equals the leader speed."""
    assert v_cmd(gap=target(), v_ego=5.0, v_lead=5.0) == pytest.approx(5.0)


def test_brakes_to_zero_when_too_close_to_a_stopped_leader():
    assert v_cmd(gap=1.0, v_ego=5.0, v_lead=0.0) == 0.0


def test_never_negative_even_when_bumpers_overlap():
    """distance < VEHICLE_LENGTH must not produce a negative command."""
    assert v_cmd(forward_distance=0.5, v_ego=5.0, v_lead=0.0) == 0.0


def test_accelerates_when_gap_exceeds_target():
    assert v_cmd(gap=target() + 3.0, v_ego=5.0, v_lead=5.0) > 5.0


def test_relative_velocity_damping_slows_ego_when_closing():
    """Same gap, ego faster than leader -> command below the leader speed."""
    assert v_cmd(gap=target(), v_ego=8.0, v_lead=5.0) < 5.0


def test_clipped_to_vehicle_v_max():
    assert v_cmd(gap=50.0, v_ego=9.0, v_lead=9.0) == pytest.approx(states.VEHICLE_V_MAX / 3.6)


def test_a_wide_corridor_closes_the_gap_to_build_a_run_up():
    """Racing behaviour: when there is room to pass, sit closer.

    ADR-037 replaced this with a speed-dependent gap and the attempt count fell
    370 -> 226 with successful passes 139 -> 103, so it was restored (ADR-040).
    """
    gap = 3.0
    narrow = v_cmd(gap=gap, overtake_width=NARROW_CORRIDOR)
    wide = v_cmd(gap=gap, overtake_width=WIDE_CORRIDOR)

    assert wide > narrow
    assert narrow == pytest.approx(
        5.0 + states.FOLLOW_K_GAP * (gap - states.FOLLOW_TARGET_DISTANCE_M))
    assert wide == pytest.approx(
        5.0 + states.FOLLOW_K_GAP * (gap - states.D0_M))


# --- 停止ルールの撤回 (ADR-043) --------------------------------------------

def test_does_not_stop_dead_for_a_vehicle_that_is_merely_close():
    """本番で発生した最悪の回帰の防止。

    `gap <= FOLLOW_STOP_DISTANCE_M` で全制動する規則を入れていたが、
    forward_vehicle_distance は横方向の離れを考慮しない。追い越しで横に出て
    いく途中に相手が前方コーン (±45度) の端へ来ると、横に 1.9m 空いていても
    距離 2.1m で発火し、24.9km/h から停止 -> stuck -> recovery に落ちていた。
    """
    inside = states.FOLLOW_STOP_DISTANCE_M - 0.1
    assert v_cmd(gap=inside, v_ego=7.0, v_lead=7.0) > 0.0


def test_the_pd_still_brakes_hard_when_genuinely_too_close():
    """撤回しても、詰まりすぎれば PD 自体が先行車速を大きく下回る指令を出す。"""
    assert v_cmd(gap=0.1, v_ego=7.0, v_lead=7.0) < 7.0


def test_never_negative_even_when_bumpers_overlap_after_the_retraction():
    assert v_cmd(forward_distance=0.5, v_ego=5.0, v_lead=0.0) == 0.0


def test_no_leader_returns_vehicle_v_max_in_mps():
    """Regression guard: this branch used to return km/h among m/s returns."""
    assert v_cmd(forward_distance=None) == pytest.approx(states.VEHICLE_V_MAX / 3.6)


def test_gains_are_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.FOLLOW_K_GAP
    gap = target() + 1.0
    try:
        states.FOLLOW_K_GAP = 0.0
        assert v_cmd(gap=gap) == pytest.approx(5.0)
        states.FOLLOW_K_GAP = 2.0
        assert v_cmd(gap=gap) == pytest.approx(7.0)
    finally:
        states.FOLLOW_K_GAP = original



# --- 横に離れた相手は追従対象にしない (ADR-043) -----------------------------

CLEAR = states.FOLLOW_LATERAL_CLEAR_M + 0.1      # 横に抜けている
# 遷移帯 [CLEAR - BLEND, CLEAR] より内側 = 完全に同一レーン扱い
IN_LANE = states.FOLLOW_LATERAL_CLEAR_M - states.FOLLOW_LATERAL_BLEND_M - 0.1


def test_a_laterally_clear_vehicle_does_not_slow_the_ego():
    """本番 v1.3.5 で起きた最悪のバグの回帰防止。

    急カーブのインを抜き終えて相手が横 1.86m・進行方向 2.10m の位置にいるとき、
    車間 PD が働いて 24.9km/h から停止し、stuck -> recovery -> 後退に落ちていた。
    前方検知の横ゲート FORWARD_LATERAL_MAX = 3.5m は追い越し判断には要るが、
    減速の判断に使ってはいけない。
    """
    assert v_cmd(forward_distance=2.10, lateral=1.86,
                 v_ego=24.88 / 3.6, v_lead=6.92 / 3.6,
                 overtake_width=2.91) == pytest.approx(states.VEHICLE_V_MAX / 3.6)


def test_a_vehicle_in_our_lane_still_slows_the_ego():
    assert v_cmd(forward_distance=2.10, lateral=IN_LANE,
                 v_ego=24.88 / 3.6, v_lead=6.92 / 3.6,
                 overtake_width=2.91) < 6.92 / 3.6


def test_the_lateral_gate_is_wider_than_a_pair_of_karts():
    """接触するのは車幅 1.45m (自車半幅 + 相手半幅) 未満のとき。"""
    assert states.FOLLOW_LATERAL_CLEAR_M > 2 * 0.725


def test_the_lateral_gate_is_narrower_than_the_detection_gate():
    """検知は広く (追い越し判断)、減速は狭く (同一レーンのみ)。"""
    assert states.FOLLOW_LATERAL_CLEAR_M < states.FORWARD_LATERAL_MAX


def test_an_unknown_lateral_offset_still_follows():
    """横偏差が取れないときは安全側 (従来どおり追従する)。"""
    ctx = make_ctx(gap=1.0, v_ego=7.0, v_lead=1.0)
    ctx.forward_vehicle_lateral = None
    assert FollowState().get_adjusted_v_max_mps(ctx) < states.VEHICLE_V_MAX / 3.6


def test_the_lateral_gate_is_read_from_module_globals():
    original = states.FOLLOW_LATERAL_CLEAR_M
    try:
        states.FOLLOW_LATERAL_CLEAR_M = 0.1   # 何もかも「横にクリア」扱い
        assert v_cmd(gap=1.0, lateral=0.5, v_ego=7.0, v_lead=1.0) == pytest.approx(
            states.VEHICLE_V_MAX / 3.6)
    finally:
        states.FOLLOW_LATERAL_CLEAR_M = original


# --- 解除は段差ではなく遷移帯 (ADR-046) -------------------------------------

def lat_cmd(lateral):
    """抜き際の典型 (中心間 2.5m / 自車 25km/h / 先行車 20km/h) での指令速度。"""
    return v_cmd(forward_distance=2.5, lateral=lateral,
                 v_ego=25.0 / 3.6, v_lead=20.0 / 3.6, overtake_width=3.0)


def test_the_release_has_no_step_at_the_gate():
    """段差のままだと V2X の横位置ノイズが境界を跨ぐたびに
    acc = KP*(u[0]-v) (KP=100 で実質バンバン制御) が全制動と全開を往復する。"""
    just_below = lat_cmd(states.FOLLOW_LATERAL_CLEAR_M - 0.02)
    just_above = lat_cmd(states.FOLLOW_LATERAL_CLEAR_M + 0.02)
    assert abs(just_above - just_below) < 0.5     # [m/s] ほぼ連続


def test_the_release_is_monotonic_across_the_band():
    lo = states.FOLLOW_LATERAL_CLEAR_M - states.FOLLOW_LATERAL_BLEND_M
    mid = states.FOLLOW_LATERAL_CLEAR_M - 0.5 * states.FOLLOW_LATERAL_BLEND_M
    assert lat_cmd(lo) < lat_cmd(mid) < lat_cmd(states.FOLLOW_LATERAL_CLEAR_M)


def test_the_release_completes_at_the_gate():
    assert lat_cmd(states.FOLLOW_LATERAL_CLEAR_M) == pytest.approx(
        states.VEHICLE_V_MAX / 3.6)


def test_below_the_band_it_is_pure_following():
    """帯より内側では従来どおり車間 PD のまま（解除ぶんを足さない）。"""
    below = states.FOLLOW_LATERAL_CLEAR_M - states.FOLLOW_LATERAL_BLEND_M - 0.2
    assert lat_cmd(below) == pytest.approx(lat_cmd(0.0))


def test_the_band_brackets_the_contact_width():
    """接触するのは車幅 1.45m 未満。帯はその内外をまたぐように置く。"""
    lo = states.FOLLOW_LATERAL_CLEAR_M - states.FOLLOW_LATERAL_BLEND_M
    assert lo < 2 * 0.725 < states.FOLLOW_LATERAL_CLEAR_M


def test_the_blend_width_is_read_from_module_globals():
    original = states.FOLLOW_LATERAL_BLEND_M
    try:
        states.FOLLOW_LATERAL_BLEND_M = 1e-9      # 実質ゼロ幅 = 従来の段差
        assert lat_cmd(states.FOLLOW_LATERAL_CLEAR_M - 0.02) == pytest.approx(
            lat_cmd(0.0))
    finally:
        states.FOLLOW_LATERAL_BLEND_M = original
