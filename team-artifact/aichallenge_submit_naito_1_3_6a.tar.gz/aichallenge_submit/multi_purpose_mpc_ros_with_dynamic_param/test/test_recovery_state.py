"""Unit tests for RecoveryState crossing attitude and boost (pure Python, no rclpy)."""

import numpy as np
import pytest

from multi_purpose_mpc_ros_with_dynamic_param import states
from multi_purpose_mpc_ros_with_dynamic_param.states import (
    GEAR_DRIVE,
    GEAR_REVERSE,
    RecoveryState,
    StateContext,
)

TICK = 1.0 / 40.0  # control loop period [s] (config.yaml: control_rate 40.0)

# Derived from the constants so retuning the thresholds does not break these tests.
# Entering with e_y > 0 latches cross_sign = -1, so a POSITIVE heading is the
# furthest from the target and never satisfies the crossing condition.
SKEWED = dict(heading_deg=+2.0 * states.RECOVERY_CROSS_ANGLE_DEG, e_y=2.0)
# Already pointing across the centerline, well past the target angle.
CROSSED = dict(heading_deg=-2.0 * states.RECOVERY_CROSS_ANGLE_DEG, e_y=2.0)


def make_ctx(t, heading_deg=30.0, e_y=2.0, publish_boost=None):
    """Context with the path running along x, so pose_theta IS the heading error."""
    return StateContext(
        current_time_sec=t,
        dt=TICK,
        state_id="ego",
        pose_x=0.0,
        pose_y=0.0,
        pose_theta=np.deg2rad(heading_deg),
        velocity=0.0,
        is_colliding=False,
        path_psi=0.0,
        path_e_y=e_y,
        publish_boost=publish_boost,
    )


def entered(e_y=2.0, **kwargs):
    """A RecoveryState that has just been entered."""
    state = RecoveryState()
    state.on_enter(make_ctx(0.0, e_y=e_y, **kwargs))
    return state


def run(state, ticks, t0=0.0, **ctx_kw):
    """Tick check_transition; return (next_state_name_or_None, ticks_consumed)."""
    for i in range(ticks):
        result = state.check_transition(make_ctx(t0 + i * TICK, **ctx_kw))
        if result is not None:
            return result, i + 1
    return None, ticks


def advance_to_phase(state, phase, max_ticks=200, **ctx_kw):
    """Tick until the state reaches ``phase``; return the next time."""
    for i in range(max_ticks):
        if state._phase == phase:
            return i * TICK
        assert state.check_transition(make_ctx(i * TICK, **ctx_kw)) is None
    raise AssertionError(f"never reached phase {phase!r}")


# --- gear / speed / acceleration ------------------------------------------

def test_back_phase_commands_reverse_gear_and_negative_speed():
    state = entered()
    advance_to_phase(state, "back", **SKEWED)
    speed, _, acc = state.compute_control_override(make_ctx(0.0, **SKEWED))
    assert state.gear == GEAR_REVERSE
    assert speed == state.RECOVERY_BACK_TURN_SPEED_MPS < 0
    assert acc == state.RECOVERY_BACK_ACCEL_MPSS


def test_forward_phase_commands_drive_gear_and_positive_speed():
    state = entered()
    advance_to_phase(state, "forward_turn", **SKEWED)
    speed, _, acc = state.compute_control_override(make_ctx(0.0, **SKEWED))
    assert state.gear == GEAR_DRIVE
    assert speed == state.RECOVERY_FORWARD_TURN_SPEED_MPS > 0
    assert acc == state.RECOVERY_FORWARD_ACCEL_MPSS


def test_reverses_on_the_very_first_tick_after_entering():
    """No `wait` phase: the entry tick already commands REVERSE and negative speed.

    StateManager does not call check_transition on the tick it enters a state, so a
    `wait` phase would leak one tick of (0, 0, 0) + GEAR_DRIVE before reversing.
    """
    state = entered()

    assert state._phase == "back"
    assert state.gear == GEAR_REVERSE

    speed, _, acc = state.compute_control_override(make_ctx(0.0, **SKEWED))
    assert speed < 0.0
    assert acc > 0.0


# --- the crossing target ---------------------------------------------------

def test_entering_left_of_the_path_targets_a_right_facing_heading():
    """path_e_y > 0 -> aim for e_psi < 0, i.e. across the centerline."""
    assert entered(e_y=+1.0)._cross_sign == -1.0


def test_entering_right_of_the_path_targets_a_left_facing_heading():
    assert entered(e_y=-1.0)._cross_sign == +1.0


def test_the_target_side_is_latched_at_entry():
    """e_y flipping sign mid-recovery must not flip the goal and stall the turn."""
    state = entered(e_y=+1.0)
    state.check_transition(make_ctx(TICK, heading_deg=0.0, e_y=-5.0))
    assert state._cross_sign == -1.0


# --- steering --------------------------------------------------------------

def steer_in(phase, heading_deg, e_y=0.0, entry_e_y=None):
    """Steering command for a given heading error.

    ``entry_e_y`` picks the crossing target (default: the same side as ``e_y``);
    ``e_y`` is the value seen when the command is computed. They differ only where
    a test needs to isolate the heading term from the lateral one.
    """
    state = entered(e_y=e_y if entry_e_y is None else entry_e_y)
    advance_to_phase(state, phase, **SKEWED)
    _, steer, _ = state.compute_control_override(
        make_ctx(0.0, heading_deg=heading_deg, e_y=e_y))
    return steer


def test_steers_hard_even_when_wedged_in_parallel_to_the_path():
    """The regression this state was rewritten for.

    Stopping with e_psi ~ 0 AND e_y ~ 0 used to give delta ~ 0, so the ego backed
    up straight and drove forward straight, ending exactly where it started.
    Targeting a crossing attitude keeps K * CROSS_ANGLE of steering on.
    """
    expected = states.RECOVERY_STEER_K * np.deg2rad(states.RECOVERY_CROSS_ANGLE_DEG)

    assert steer_in("back", 0.0, e_y=0.0) == pytest.approx(+expected)
    assert steer_in("forward_turn", 0.0, e_y=0.0) == pytest.approx(-expected)


def test_back_steers_toward_the_crossing_target():
    """Reversing (v < 0): psi_dot = v/L * tan(delta), so delta shares the error's sign.

    Entering left of the path (cross_sign = -1) means every heading above the
    -CROSS_ANGLE target needs positive steering to swing the nose right.
    """
    assert steer_in("back", +20.0, entry_e_y=+1.0) > 0.0
    assert steer_in("back", -20.0, entry_e_y=-1.0) < 0.0


def test_forward_steers_opposite_to_the_back_phase():
    """Driving forward (v > 0): the sign flips to keep turning the same way."""
    assert steer_in("forward_turn", +20.0, entry_e_y=+1.0) < 0.0
    assert steer_in("forward_turn", -20.0, entry_e_y=-1.0) > 0.0


def test_steer_is_proportional_to_the_error_from_the_target_below_the_lock():
    heading_deg = -states.RECOVERY_CROSS_ANGLE_DEG + 10.0  # 10 deg short of the target
    expected = states.RECOVERY_STEER_K * np.deg2rad(10.0)
    assert expected < RecoveryState.RECOVERY_STEER_LOCK_RAD  # guard: below the clip

    assert steer_in("back", heading_deg) == pytest.approx(expected)
    assert steer_in("forward_turn", heading_deg) == pytest.approx(-expected)


def test_steer_stops_when_the_target_attitude_is_reached():
    """At the target the heading term vanishes; only the lateral term is left."""
    at_target = -states.RECOVERY_CROSS_ANGLE_DEG  # cross_sign = -1 for e_y >= 0
    assert steer_in("back", at_target, e_y=0.0) == pytest.approx(0.0)


def test_steer_clips_to_the_lock_for_large_errors():
    lock = RecoveryState.RECOVERY_STEER_LOCK_RAD
    assert steer_in("back", +90.0) == pytest.approx(+lock)
    assert steer_in("forward_turn", +90.0) == pytest.approx(-lock)


def test_lateral_offset_also_steers_back_toward_the_centerline():
    """Reversing left of the path swings the rear right, so e_y > 0 steers left."""
    at_target = -states.RECOVERY_CROSS_ANGLE_DEG
    assert steer_in("back", at_target, e_y=+1.0) > 0.0
    assert steer_in("back", -at_target, e_y=-1.0, entry_e_y=-1.0) < 0.0


def test_forward_lateral_term_has_the_opposite_sign():
    at_target = -states.RECOVERY_CROSS_ANGLE_DEG
    assert steer_in("forward_turn", at_target, e_y=+1.0) < 0.0
    assert steer_in("forward_turn", -at_target, e_y=-1.0, entry_e_y=-1.0) > 0.0


def test_steer_gain_is_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.RECOVERY_STEER_K
    try:
        states.RECOVERY_STEER_K = 0.0
        assert steer_in("back", +20.0, e_y=0.0) == pytest.approx(0.0)

        states.RECOVERY_STEER_K = 0.5
        err = np.deg2rad(20.0 + states.RECOVERY_CROSS_ANGLE_DEG)
        assert steer_in("back", +20.0, e_y=0.0) == pytest.approx(0.5 * err)
    finally:
        states.RECOVERY_STEER_K = original


# --- early exit -----------------------------------------------------------

def test_the_back_phase_ends_once_the_crossing_attitude_is_reached():
    """back's job is to CREATE the crossing attitude, so that is its exit."""
    state = entered()
    t = advance_to_phase(state, "forward_turn", **CROSSED)
    assert t == pytest.approx(states.RECOVERY_MIN_PHASE_SEC, abs=3 * TICK)


def test_the_forward_phase_does_not_end_on_the_crossing_alone():
    """The regression this split was made for.

    Sharing back's exit condition made forward_turn end at exactly
    RECOVERY_MIN_PHASE_SEC — back had already satisfied it — so the ego handed
    back to follow_path without ever driving back to the racing line.
    """
    state = entered()
    t = advance_to_phase(state, "forward_turn", **CROSSED)

    # Still crossed, but far off the centerline: forward must keep going.
    result, _ = run(state, int(1.0 / TICK), t0=t, **CROSSED)
    assert result is None
    assert abs(CROSSED["e_y"]) > states.RECOVERY_RETURN_E_Y_M  # guard on the fixture


def test_returns_to_follow_path_once_back_near_the_centerline():
    near = 0.5 * states.RECOVERY_RETURN_E_Y_M
    state = entered()
    t = advance_to_phase(state, "forward_turn", **CROSSED)

    result, ticks = run(state, 400, t0=t, heading_deg=CROSSED["heading_deg"], e_y=near)
    assert result == "follow_path"
    assert ticks * TICK == pytest.approx(states.RECOVERY_MIN_PHASE_SEC, abs=3 * TICK)


def test_a_recovery_that_starts_already_crossed_still_moves():
    """Without a minimum phase time the ego would leave without a single tick of
    reversing, get stuck again, and ping-pong through recovery."""
    state = entered()
    result, _ = run(state, int(states.RECOVERY_MIN_PHASE_SEC / TICK) - 1, **CROSSED)
    assert result is None
    assert state._phase == "back"


def test_falls_back_to_the_timeout_when_the_crossing_is_never_reached():
    state = entered()
    timeout = (
        RecoveryState.BACK_DURATION_TIME_SEC
        + RecoveryState.FORWARD_DURATION_TIME_SEC
    )
    result, ticks = run(state, 400, **SKEWED)
    assert result == "follow_path"
    assert ticks * TICK == pytest.approx(timeout, abs=3 * TICK)


def test_each_phase_gets_its_own_duration():
    """Leaving `back` early must not lengthen or shorten `forward_turn`."""
    state = entered()

    # Crossed -> back ends as soon as the minimum phase time is up.
    t = advance_to_phase(state, "forward_turn", **CROSSED)
    assert t == pytest.approx(states.RECOVERY_MIN_PHASE_SEC, abs=3 * TICK)

    # Now skewed again: forward_turn must still get its full duration.
    result, ticks = run(state, 400, t0=t, **SKEWED)
    assert result == "follow_path"
    assert ticks * TICK == pytest.approx(
        RecoveryState.FORWARD_DURATION_TIME_SEC, abs=2 * TICK
    )


def test_crossing_threshold_is_read_from_module_globals_at_call_time():
    """ROS params are applied via setattr(states, ...), so no capture at import."""
    original = states.RECOVERY_CROSS_ANGLE_DEG
    heading = -original - 1.0  # just past the default target, short of a doubled one
    ticks = int(states.RECOVERY_MIN_PHASE_SEC / TICK) + 4
    try:
        states.RECOVERY_CROSS_ANGLE_DEG = 2.0 * original
        state = entered()
        run(state, ticks, heading_deg=heading)
        assert state._phase == "back"  # no longer far enough across

        states.RECOVERY_CROSS_ANGLE_DEG = original
        state = entered()
        run(state, ticks, heading_deg=heading)
        assert state._phase == "forward_turn"
    finally:
        states.RECOVERY_CROSS_ANGLE_DEG = original


def test_return_threshold_is_read_from_module_globals_at_call_time():
    original = states.RECOVERY_RETURN_E_Y_M
    ticks = int(states.RECOVERY_MIN_PHASE_SEC / TICK) + 4
    try:
        state = entered()
        t = advance_to_phase(state, "forward_turn", **CROSSED)

        states.RECOVERY_RETURN_E_Y_M = 0.5 * abs(CROSSED["e_y"])
        assert run(state, ticks, t0=t, **CROSSED)[0] is None

        states.RECOVERY_RETURN_E_Y_M = 2.0 * abs(CROSSED["e_y"])
        assert run(state, ticks, t0=t, **CROSSED)[0] == "follow_path"
    finally:
        states.RECOVERY_RETURN_E_Y_M = original


# --- boost ----------------------------------------------------------------

def test_on_exit_turns_boost_on():
    published = []
    state = entered()
    state.on_exit(make_ctx(1.0, publish_boost=published.append))
    assert published == [states.RECOVERY_BOOST_VALUE]


def test_on_exit_without_a_boost_publisher_does_not_raise():
    state = entered()
    state.on_exit(make_ctx(1.0, publish_boost=None))


# --- 舵角の向きは停止側で固定される (ADR-044) ------------------------------

def steer_pair(e_y, heading_deg):
    """(後退の舵角, 前進の舵角) を返す。"""
    state = entered(e_y=e_y, heading_deg=heading_deg)
    back = state.compute_control_override(make_ctx(0.0, heading_deg=heading_deg, e_y=e_y))[1]
    state._phase = "forward_turn"
    fwd = state.compute_control_override(make_ctx(0.0, heading_deg=heading_deg, e_y=e_y))[1]
    return back, fwd


# 角度差が目標を越えている領域を必ず含める。以前はゲイン項が符号を握っていたため、
# e_y > 0 で e_psi < -40 度 のとき後退の舵角が負に反転していた。
CONTRACT_HEADINGS = (80.0, 40.0, 20.0, 0.0, -20.0, -40.0, -60.0, -80.0)


def test_stopping_left_always_backs_with_left_steering():
    """契約: センターラインの左で停止 -> 後退は左 (>0)、前進は右 (<0)。"""
    for deg in CONTRACT_HEADINGS:
        back, fwd = steer_pair(+1.0, deg)
        assert back > 0.0, f"e_psi={deg} で後退が右に切れている"
        assert fwd < 0.0, f"e_psi={deg} で前進が左に切れている"


def test_stopping_right_always_backs_with_right_steering():
    """契約: センターラインの右で停止 -> 後退は右 (<0)、前進は左 (>0)。"""
    for deg in CONTRACT_HEADINGS:
        back, fwd = steer_pair(-1.0, deg)
        assert back < 0.0, f"e_psi={deg} で後退が左に切れている"
        assert fwd > 0.0, f"e_psi={deg} で前進が右に切れている"


def test_the_steering_side_is_latched_at_entry():
    """復帰中に e_y の符号が変わっても舵角の向きは動かさない。"""
    state = entered(e_y=+1.0)
    flipped = state.compute_control_override(make_ctx(0.0, heading_deg=0.0, e_y=-5.0))[1]
    assert flipped > 0.0


def test_the_magnitude_still_grows_with_the_attitude_error():
    """向きを固定しても、大きさは目標姿勢との角度差に比例したまま。"""
    at_target = -states.RECOVERY_CROSS_ANGLE_DEG
    near = abs(steer_pair(+1.0, at_target + 5.0)[0])
    far = abs(steer_pair(+1.0, at_target + 25.0)[0])
    assert far > near


def test_the_magnitude_is_clipped_at_the_lock():
    lock = RecoveryState.RECOVERY_STEER_LOCK_RAD
    assert steer_pair(+1.0, 90.0)[0] == pytest.approx(lock)
    assert steer_pair(-1.0, -90.0)[0] == pytest.approx(-lock)
